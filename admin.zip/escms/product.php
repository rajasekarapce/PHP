<?php include "header.php"; ?>
            <!--===================================================-->
            <!--END NAVBAR-->
            <div class="boxed">
                <!--CONTENT CONTAINER-->
                <!--===================================================-->
                <div id="content-container">
                    <?php include "header_nav.php"; ?>
                    <div class="pageheader">
                        <h3><i class="fa fa-users"></i> Product </h3>
                        <div class="breadcrumb-wrapper">
                            <span class="label">You are here:</span>
                            <ol class="breadcrumb">
                                <li> <a href="welcome.php"> Home </a> </li>
                                <li class="active">Product </li>
                            </ol>
                        </div>
                    </div>
<?php
$status = isSet($status) ? $status : '' ;
$id = isSet($id) ? $id : '' ;
$act = isSet($act) ? $act : '' ;
$Message = isSet($Message) ? $Message : '' ;
$records = $GT_RecPerPage;

if($act=="del"){
	$getrec1=$db->singlerec("select prodimg,prodimg2,prodimg3,prodimg4 from product where id='$id'");
	$prodimg=$getrec1['prodimg']; $prodimg2=$getrec1['prodimg2']; $prodimg3=$getrec1['prodimg3']; $prodimg4=$getrec1['prodimg4'];
	if($prodimg !="noimages.jpg"){@unlink("../uploads/prodimg/40x40/$prodimg");@unlink("../uploads/prodimg/400x400/$prodimg");}
	if($prodimg2 !="noimages.jpg"){@unlink("../uploads/prodimg/40x40/$prodimg2");@unlink("../uploads/prodimg/400x400/$prodimg2");}
	if($prodimg3 !="noimages.jpg"){@unlink("../uploads/prodimg/40x40/$prodimg3");@unlink("../uploads/prodimg/400x400/$prodimg3");}
	if($prodimg4 !="noimages.jpg"){@unlink("../uploads/prodimg/40x40/$prodimg4");@unlink("../uploads/prodimg/400x400/$prodimg4");}
    $db->insertrec("delete from product where id='$id'");
    header("location:product.php?act='del'");
    exit ;
}

if($status == "1") {
    $db->insertrec("update product set prod_status='0' where id='$id'");
    header("location:product.php?act=sts");
    exit ;
}
else if($status == "0") {
    $db->insertrec("update product set prod_status='1' where id='$id'");
    header("location:product.php?act=sts");
    exit ;
}
$GetRecord=$db->get_all("select * from product order by id desc");
if(count($GetRecord)==0)
    $Message="No Record found";
$disp = "";
for($i = 0 ; $i < count($GetRecord) ; $i++) {
   @extract($GetRecord[$i]);   
	$slno = $i + 1 ;
    $idvalue = $GetRecord[$i]['id'];
	$prod_name=$GetRecord[$i]['prod_name'];
	$prod_category=$GetRecord[$i]['prod_cat'];	
	$prod_price=$GetRecord[$i]['prod_minprice'];
	$prodimg=$GetRecord[$i]['prodimg'];
	$prod_status=$GetRecord[$i]['prod_status'];
	$saletype=$GetRecord[$i]['saletype'];
	$max_supply_quantity=$GetRecord[$i]['max_supply_quantity'];
	$prod_keyword=$GetRecord[$i]['prod_keyword'];
	$mutikeywords=$GetRecord[$i]['mutikeywords'];
	if($saletype !=0){$saletype=$PS_Sale[$saletype];}else{$saletype="";}	
	$slno = $i + 1 ;
    if($prod_status == '0'){
        $DisplayStatus = $GT_InActive;
		$Title = "Active";
		$status_active = "Deactive";
		$EditLink = "<a class='btn btn-default' ><i class='fa ><font color='red'>--</font></i></a>";
	}	
    else if($prod_status == '1'){
        $DisplayStatus = $GT_Active;
		$Title = "Deactive";
		$status_active = "Active";
		$EditLink = "<a href='productupd.php?upd=2&id=$idvalue' title='Edit' class='btn btn-default' ><i class='fa fa-edit'></i></a>";
	}
	$links="";
	if($userurl !="")
		$links .="<a href='$userurl' target='_blank'>userdemo</a>";
	if($adminurl !="")
		$links .=" | <a href='$adminurl' target='_blank'>admindemo</a>";
	
	
    $disp .="<tr><td width='5%'>$slno</td>
				<td  align='left'  width='10%'><img src='../uploads/prodimg/40x40/$prodimg'></td>
				<td  align='left' width='10%'>$prod_category</td>
				<td  align='left'  width='10%'>$prod_name</td>
				<td  align='left'  width='10%'>$prod_price</td>
				<td>$links</td>
				<td>$prod_keyword</td>
				<td>$mutikeywords</td>
				<td width='30%'>
				<div class='btn-group btn-group-xs'>
				<a href='rating.php?rid=$idvalue' class='btn btn-default' title='Rating' data-toggle='tooltip'>Rating</a>
				<a href='productview.php?id=$idvalue' title='View Product Details' class='btn btn-default' data-toggle='tooltip'>$GT_View</a>
					<a href='product.php?id=$idvalue&status=$prod_status' title='$Title' class='btn btn-default' data-toggle='tooltip'>$DisplayStatus</a>
					$EditLink
					<a href='product.php?id=$idvalue&act=del' class='btn btn-default' title='Delete' data-toggle='tooltip'>$GT_Delete</a>
				</div>
				</td>
			</tr>";
}
if($act == "'del'")
    $Message = "<font color='green'><b>Deleted Successfully</b></font>" ;
else if($act == "upd")
    $Message = "<font color='green'><b>Updated Successfully</b></font>" ;
else if($act == "add")
    $Message = "<font color='green'><b>Added Successfully</b></font>" ;
else if($act == "sts")
    $Message = "<font color='green'><b>Status Changed Successfully</b></font>" ;
?>
                    <!--Page content-->
                    <!--===================================================-->
                    <div id="page-content">
                        <!-- Basic Data Tables -->
                        <!--===================================================-->
                        <div class="panel">
                            <div class="panel-heading">
                                <h3 class="panel-title"><?php echo $Message;?></h3>
                            </div>
                            <div class="panel-body">
							<div class="col-sm-12 text-right"><a class="btn btn-info" href="productupd.php?upd=1">Add New</a></div>
                                <table id="demo-dt-basic" class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
											<th>Sl.no</th>
											<th>Image</th>
											<th>Category</th>
											<th>ProductName</th>
											<th>Price</th>
											<th>Link</th>
											<th>SEO Keywords</th>
											<th>Multiple Keywords</th>
											<th class='cntrhid'>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody><?php echo $disp; ?></tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <!--===================================================-->
                    <!--End page content-->
                </div>
                <!--===================================================-->
                <!--END CONTENT CONTAINER-->
			<?php include "leftmenu.php"; ?>	
            </div>
<?php include "footer.php"; ?>