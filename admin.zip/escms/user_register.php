<?php include "header.php"; 

$upd = isset($upd)?$upd:'';
$id = isSet($id) ? $id : '' ;
$act  = isSet($act) ? $act : '' ;
$page  = isSet($page) ? $page : '' ;
$Message   = isSet($Message) ? $Message : '' ;
$decript_password = isset($decript_password)?$decript_password:'';
$password  = isSet($password) ? $password : '' ;
$name  = isSet($name) ? $name : '' ;
$mobile  = isSet($mobile) ? $mobile : '' ;
$email  = isSet($email) ? $email : '' ;
$chgne  = isSet($chgne) ? $chgne : '' ;
$psw = isset($psw)?$psw:'';
$ImgExt = isSet($ImgExt) ? $ImgExt : '' ;
$DisplayDeleteImgLink = isSet($DisplayDeleteImgLink) ? $DisplayDeleteImgLink : '' ;
$hidimg = isSet($hidimg) ? $hidimg : '' ;

if($act ==  "del" && $nimg != "") {
    $RemoveImage = "../images/userimages/$nimg";
    @unlink($RemoveImage);
    $db->insertrec("update register set userimages='noimage.jpg' where id='$id'");
    header("Location:registerupd.php?upd=2&msg=nimgscs&id=$id") ;
    exit ;
}
if($submit) {
    $crcdt = date('y-m-d');
    $name = trim(addslashes($name));
	$password_length = strlen($password);
	$decript_password = $password;
	$password = trim(addslashes(md5($decript_password)));
	$mobile = trim(addslashes($mobile));
	$email = trim(addslashes($email));
	$first_name = trim(addslashes($first_name));
	$last_name = trim(addslashes($last_name));
	$website_url = trim(addslashes($website_url));
	$twitter_url = trim(addslashes($twitter_url));
	$google_url = trim(addslashes($google_url));
	$facebook_url = trim(addslashes($facebook_url));
	
$checkStatus1=$db->check1column("register","name",$name);
$checkStatus2=$db->check1column("register","email",$email);
if($upd == 2){
			$checkStatus1 = 0;
			$checkStatus2 = 0;
			}
	if($_FILES['UsrImage']['tmp_name'] != "" && $_FILES['UsrImage']['tmp_name'] != "null") {
		$fpath = $_FILES['UsrImage']['tmp_name'] ;
		$fname = $_FILES['UsrImage']['name'] ;
		$getext = substr(strrchr($fname, '.'), 1);
		$Img_Ext = strtolower($getext); 
	}
	if($Img_Ext == "jpg" || $Img_Ext == "jpeg" || $Img_Ext == "gif" || $Img_Ext == "png" || $Img_Ext == ''){
if($checkStatus1==0){
	if($checkStatus2==0){
			$set  = "name = '$name'"; 
			$set  .= ",mobile = '$mobile'";
			$set  .= ",email = '$email'";	
			$set  .= ",first_name = '$first_name'"; 
			$set  .= ",last_name = '$last_name'";
			$set  .= ",email = '$email'";	
			$set  .= ",website_url = '$website_url'"; 
			$set  .= ",twitter_url = '$twitter_url'";
			$set  .= ",google_url = '$google_url'";	
			$set  .= ",facebook_url = '$facebook_url'";	
			if($password !=""){
				$set  .= ",password = '$decript_password'";  		
				$set  .= ",decript_password = '$password'";
			}
			if($upd == 1){
				$set  .= ",crcdt = '$crcdt'";    
				$set  .= ",active_status = '1'";
				$set  .= ",crcusr  = '$crcusr '";
				$idvalue = $db->insertid("insert into register set $set");
				$act = "add";
			}
			else if($upd == 2){
				$set  .= ",chngdt = '$crcdt'";    
				$set  .= ",chgne = '$chgne'";
				$db->insertrec("update register set $set where id='$idvalue'");
				$act = "upd";
			}
			if($_FILES['UsrImage']['tmp_name'] != "" && $_FILES['UsrImage']['tmp_name'] != "null") {
		$fpath = $_FILES['UsrImage']['tmp_name'];
		$fname = $_FILES['UsrImage']['name'] ;
		$getext = substr(strrchr($fname, '.'), 1);
		$ext = strtolower($getext);
		$NgImg= $idvalue.".".$ext;
		$set_img = "userimages = '$NgImg'" ;
		$des = "../images/userimages/$NgImg";
		move_uploaded_file($fpath,$des) ;
		chmod($des,0777);
		$iimg=$db->insertrec("select userimages from register where id='$idvalue'");
					if($iimg!= "noimage.jpg") {
						$RemoveImage = "../images/userimages/$nimg";
						@unlink($RemoveImage);
					}
		$db->insertrec("update register set $set_img where id='$idvalue'");
	}
			echo "<script>location.href='register.php?act=$act';</script>";
			header("location:register.php?act=$act");
			exit;	
		}	
		else{
$act=="exit_email";
echo "<script>location.href='registerupd.php?act=exit_email'</script>";
}
}

else{
$act=="exit_nam";
echo "<script>location.href='registerupd.php?act=exit_nam'</script>";
}
}
else{
		$id = $idvalue;
		$Message = "<font color='red'>kindly upload jpg,gif,png image format only</font>";
	}
}		
$GetRecord = $db->singlerec("select * from register where id='$id'");
@extract($GetRecord);


if($upd==2){
	$TextChange = "Edit";
	if($psw == 1){$passshow = "<b><font color='green'>Your password is : $password</font></b>";}
else{$passshow = "<span><a href='registerupd.php?upd=$upd&id=$id&page=$page&psw=1'>Get Password</a></span>";}
}
else{
	$TextChange = "Creat";
	$passshow = "";
}

if($upd==2){
	$TextChange = "Edit";
	$imghid = "";
	
}
else{
	$TextChange = "Creat";
	$imghid = "style='display:none;'";
}
if($act == "ps")
	$Message = "<b><font color='red'>atleast 4 minimum character need!!!...</font></b>";
if($act=="exit_nam")
	$Message="<b><font color='red'>Username already exits.</font><b>";
if($act=="exit_email")
	$Message="<b><font color='red'>Email-ID already exits.</font><b>";
	
//code for images 
if($userimages == "noimage.jpg") {
        $ShowOldImg = "";
   $DisplayDeleteImgLink = '';
    }
else if($userimages != "") {
        $ShowOldImg = "";
   $DisplayDeleteImgLink = '<a href="registerupd.php?upd=2&act=del&nimg='.$userimages.'&id='.$id.'">Delete</a>';
    }
?>
<div class="boxed">
	<!--CONTENT CONTAINER-->
	<!--===================================================-->
	<div id="content-container">
		<?php include "header_nav.php"; ?>
		<div class="pageheader">
			<h3><i class="fa fa-users"></i>User </h3>
			<div class="breadcrumb-wrapper">
				<span class="label">You are here:</span>
				<ol class="breadcrumb">
					<li> <a href="welcome.php"> Home </a> </li>
					<li class="active"> User </li>
				</ol>
			</div>
		</div>
		<!--Page content-->
		<!--===================================================-->
		<div id="page-content">
			<div class="row">
			  <div class="eq-height">
				 <div class="col-sm-6 eq-box-sm">
					<div class="panel">
						<div class="panel-heading">
							<h3 class="panel-title"><?php echo $TextChange;?> User <?php echo $Message;?></h3>
						</div>
						<form class="form-horizontal" method="post" action="" enctype="multipart/form-data">
							<input type="hidden" name="idvalue" value="<?php echo $id;?>" />
							<input type="hidden" name="upd" value="<?php echo $upd;?>" />
							<div class="panel-body">
								<table style="padding:25px;">
									<tr>
										<td>Name <font color="red">*</font></td>
										<td><input type="text" name="name" class="form-control" id="name" value="<?php echo $name; ?>">
										</td>
									</tr>
									<tr>
										<td>Password <font color="red">*</font></td>
										<td><input type="password" class="form-control" id="password" name="password" size="40"  value="" placeholder="*****" >
										<?php echo $passshow; ?>
										</td>
									</tr>
									<tr>
										<td>Email Id <font color="red">*</font></td>
										<td><input type="email" class="form-control" id="email" name="email" value="<?php echo $email; ?>"></td>
									</tr>
									<tr>
										<td>Image</td>
										<td><span <?php echo $imghid;?>><img src="../images/userimages/<?php echo $userimages; ?>" width="120px" height="120px"><br><?php echo $DisplayDeleteImgLink; ?></span>
										<input name="UsrImage" type="file"></td>
									<tr>
									<tr>
										<td>First Name<font color="red">*</font></td>
										<td><input type="text" class="form-control" id="first_name" name="first_name" value="<?php echo $first_name; ?>"></td>
									</tr>
									<tr>
										<td>Last Name<font color="red">*</font></td>
										<td><input type="text" class="form-control" id="last_name" name="last_name" value="<?php echo $last_name; ?>"></td>
									</tr>
									<tr>
										<td>Website Url<font color="red">*</font></td>
										<td><input type="text" class="form-control" id="website_url" name="website_url" value="<?php echo $website_url; ?>"></td>
									</tr>
									<tr>
										<td>Twitter Url<font color="red">*</font></td>
										<td><input type="text" class="form-control" id="twitter_url" name="twitter_url" value="<?php echo $twitter_url; ?>"></td>
									</tr><tr>
										<td>Facebook Url<font color="red">*</font></td>
										<td><input type="text" class="form-control" id="facebook_url" name="facebook_url" value="<?php echo $facebook_url; ?>"></td>
									</tr><tr>
										<td>Google Url<font color="red">*</font></td>
										<td><input type="text" class="form-control" id="google_url" name="google_url" value="<?php echo $google_url; ?>"></td>
									</tr>
										<td></td><td colspan="3"><span id="DispResign"></span></td>
									</tr>
								</table>
							</div>
							<div class="panel-footer text-left">
								<div class="col-md-4  text-right"><input class="btn btn-info" type="submit" name="submit" value="Save"></div>
								<a class="btn btn-info" href="register.php">Cancel</a>
							</div>
						</form>
						<!--===================================================-->
						<!--End Horizontal Form-->
					</div>
				</div>
			  </div>
			</div>
		</div>
		<!--===================================================-->
		<!--End page content-->
	</div>
	<!--===================================================-->
	<!--END CONTENT CONTAINER-->
	<?php include "leftmenu.php"; ?>
</div>
<?php include "footer.php"; ?>