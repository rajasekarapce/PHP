<?php include"header.php"; ?>
<div class="boxed">
	<!--CONTENT CONTAINER-->
	<!--===================================================-->
	<div id="content-container">
		<?php include "header_nav.php"; ?>
		<div class="pageheader">
			<h3><i class="fa fa-home"></i>Area </h3>
			<div class="breadcrumb-wrapper">
				<span class="label">You are here:</span>
				<ol class="breadcrumb">
					<li> <a href="welcome.php"> Home </a> </li>
					<li class="active"> Area </li>
				</ol>
			</div>
		</div>
		
<?php
$id  = isSet($id) ? $id : '' ;
$act  = isSet($act) ? $act : '' ;
$page  = isSet($page) ? $page : '' ;
$Message  = isSet($Message) ? $Message : '' ;
$name = isSet($name) ? $name : '' ;

if($submit) {
    $crcdt = time();
    $name  = trim(addslashes($name));
	$checkStatus = $db->check1column("pincode","name",$name);
	if($name != ''){
		if($upd == 2)
			$checkStatus = 0;
			
		if($checkStatus == 0){
			$set  = "name = '$name'";
			if($upd == 1){ 
				$set  .= ",active_status = '1'";
				$db->insertrec("insert into pincode set $set");
				$act = "add";
			}
			else if($upd == 2){
				$db->insertrec("update pincode set $set where id='$idval'");
				$act = "upd";
			}
			header("location:pincode.php?act=$act");
			exit;
			}
			else{
			$upd = $upd ;
			$Message = "<font color='red'>$name Already Exit</font>";
		}
    } 
	else{
		$upd = $upd ;
		$Message = "<font color='red'>Input Fields Marked With * are compulsory</font>";
	}
}
if($upd==1){
	$TextChange = "Add";
}
else if($upd==2){
	$TextChange = "Update";
	$Getmaincat=$db->singlerec("select * from pincode where id='$id'");
    $name = stripslashes($Getmaincat['name']);
}

?>
		
			<!--Page content-->
		<!--===================================================-->
		<div id="page-content">
			<div class="row">
			  <div class="eq-height">
				 <div class="col-sm-6 eq-box-sm">
					<div class="panel">
						<div class="panel-heading">
							<h3 class="panel-title"><?php echo $TextChange;?> Pincode</h3>
						</div>
						<form class="form-horizontal" method="post" action="">
							<input type="hidden" name="idval" value="<?php echo $id;?>" />
							<input type="hidden" name="upd" value="<?php echo $upd;?>" />							
							<div class="panel-body">
								<table style="padding:25px;">
									<tr>
										<td>pincode <font color="red">*</font></td>
										<td><input type="text" name="name" value="<?php echo $name; ?>" class="form-control" required>
										</td>
									</tr>
							    </table>
							</div>
							<div class="panel-footer text-left">
								<div class="col-md-4  text-right"><input class="btn btn-info" type="submit" name="submit" value="Submit"></div>
								<a class="btn btn-info" href="pincode.php">Cancel</a>
							</div>
						</form>
						<!--===================================================-->
						<!--End Horizontal Form-->
					</div>
				</div>
			  </div>
			</div>
		</div>
		<!--===================================================-->
		<!--End page content-->
	</div>
	<!--===================================================-->
	<!--END CONTENT CONTAINER-->
	<?php include "leftmenu.php"; ?>
</div>
<?php include "footer.php"; ?>