function confirm(){
	alert("Are you sure to delete?");
} 