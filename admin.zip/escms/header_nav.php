<div id="profilebody">
	<div class="pad-all animated fadeInDown">
		<div class="row">
			<div class="col-lg-2 col-sm-6 col-md-6 col-xs-12">
				<div class="panel panel-default mar-no">
					<div class="panel-body">
						<a href="JavaScript:void(0);">
							<div class="pull-left">
								<p class="profile-title text-bricky">Users</p>
							</div>
							<div class="pull-right text-bricky"> <i class="fa fa-users fa-4x"></i> </div>
						</a>
					</div>
				</div>
			</div>
			<div class="col-lg-2 col-sm-6 col-md-6 col-xs-12">
				<div class="panel panel-default mar-no">
					<div class="panel-body">
						<a href="JavaScript:void(0);">
							<div class="pull-left">
								<p class="profile-title text-bricky">Inbox</p>
							</div>
							<div class="pull-right text-bricky"> <i class="fa fa-envelope fa-4x"></i> </div>
						</a>
					</div>
				</div>
			</div>
			<div class="col-lg-2 col-sm-6 col-md-6 col-xs-12">
				<div class="panel panel-default mar-no">
					<div class="panel-body">
						<a href="JavaScript:void(0);">
							<div class="pull-left">
								<p class="profile-title text-bricky">FAQ</p>
							</div>
							<div class="pull-right text-bricky"> <i class="fa fa-headphones fa-4x"></i> </div>
						</a>
					</div>
				</div>
			</div>
			<div class="col-lg-2 col-sm-6 col-md-6 col-xs-12">
				<div class="panel panel-default mar-no">
					<div class="panel-body">
						<a href="JavaScript:void(0);">
							<div class="pull-left">
								<p class="profile-title text-bricky">Settings</p>
							</div>
							<div class="pull-right text-bricky"> <i class="fa fa-cogs fa-4x"></i> </div>
						</a>
					</div>
				</div>
			</div>
			<div class="col-lg-2 col-sm-6 col-md-6 col-xs-12">
				<div class="panel panel-default mar-no">
					<div class="panel-body">
						<a href="JavaScript:void(0);">
							<div class="pull-left">
								<p class="profile-title text-bricky">Calender</p>
							</div>
							<div class="pull-right text-bricky"> <i class="fa fa-calendar fa-4x"></i> </div>
						</a>
					</div>
				</div>
			</div>
			<div class="col-lg-2 col-sm-6 col-md-6 col-xs-12">
				<div class="panel panel-default mar-no">
					<div class="panel-body">
						<a href="JavaScript:void(0);">
							<div class="pull-left">
								<p class="profile-title text-bricky">Pictures</p>
							</div>
							<div class="pull-right text-bricky"> <i class="fa fa-picture-o fa-4x"></i> </div>
						</a>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>