<?php include "header.php"; 

$upd = isset($upd) ? $upd:'';
$id = isSet($id) ? $id : '' ;
$act  = isSet($act) ? $act : '' ;
$page  = isSet($page) ? $page : '' ;
$Message  = isSet($Message) ? $Message : '' ;
$fname=isSet($fname) ? $fname : '' ;
$email=isSet($email) ? $email : '' ;
$password=isSet($password) ? $password : '' ;
$cpassword=isSet($cpassword) ? $cpassword : '' ;
$address1=isSet($address1) ? $address1 : '' ;
$mobile=isSet($mobile) ? $mobile : '' ;

if($submit) {
	$crcdt = date("Y-m-d");
	$pass=md5($password);
	$set  = "fname = '$fname'";
	$set  .= ",email = '$email'"; 
	$set  .= ",password = '$pass'";
	$set  .= ",decript_password = '$password'";
	$set  .= ",address1 = '$address1'";
	$set  .= ",mobile = '$mobile'";
	//echo "-----------------------------------------------------------".$set; exit;
	if($upd == 1){
		$set  .= ",active_status = '1'";
		$set  .= ",crcdt = '$crcdt'";
		$idvalue=$db->insertid("insert into register set $set");
		$act = "add";
	}
	else if($upd == 2){
		$set  .= ",chngdt = '$crcdt'";    
		$db->insertrec("update register set $set where id='$idval'");
		$act = "upd";
	}
	echo "<script>location.href='user_role.php?act=$act';</script>";
	header("location:user.php?act=$act");
	exit;	
}
		
$GetRecord = $db->singlerec("select * from register where id='$id'");
@extract($GetRecord);
$fname=strtolower($fname);
$email=strtolower($email);
$password=strtolower($password);
$cpassword=strtolower($cpassword);
$address1=strtolower($address1);
$mobile=strtolower($mobile);

if($act == "ps")
	$Message = "<b><font color='red'>atleast 4 minimum character need!!!...</font></b>";
if($act=="exit_nam")
	$Message="<b><font color='red'>Username already exits.</font><b>";
if($act=="exit_email")
	$Message="<b><font color='red'>Email-ID already exits.</font><b>";
?>
<script src="js/add_delRow.js" type="text/javascript"></script>
<div class="boxed">
	<!--CONTENT CONTAINER-->
	<!--===================================================-->
	<div id="content-container">
		<?php include "header_nav.php"; ?>
		<div class="pageheader">
			<h3><i class="fa fa-users"></i>User </h3>
			<div class="breadcrumb-wrapper">
				<span class="label">You are here:</span>
				<ol class="breadcrumb">
					<li> <a href="welcome.php"> Home </a> </li>
					<li class="active"> User </li>
				</ol>
			</div>
		</div>
		<!--Page content-->
		<!--===================================================-->
		<div id="page-content">
            <div class="row">
                <div class="col-md-12">
                    <section class="panel">
                        <div class="panel-heading">
                            <h3 class="panel-title">User <?php echo $Message;?></h3>
                         </div>
                         <div class="panel-body">
                         <!-- START Form Wizard -->
                            <form class="form-horizontal form-bordered form-wizard" action="" id="wizard-validate" name="wizard-validate">
                            <input type="hidden" name="idval" value="<?php echo $id;?>">
							<input type="hidden" name="upd" value="<?php echo $upd;?>">
                                            <div class="wizard-container">
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-md-3">
                                                            <label>First Name: <span class="text-danger">*</span></label>
                                                            <input type="text" name="fname" id="fname" placeholder="First Name" class="form-control" value="<?php echo $fname; ?>" />
                                                        </div>
														
                                                    </div>
                                                </div>
										<div class="form-group">                                            
                                            <div class="row">
                                                <div class="col-md-3">
                                                            <label>Email Id(As Username): <span class="text-danger">*</span></label>
                                                            <input type="text" name="email" id="email" placeholder="Email Id" class="form-control" value="<?php echo $email; ?>" />
                                                        </div>
														<div class="col-md-3">
                                                            <label>Password: <span class="text-danger">*</span></label>
                                                            <input type="text" name="password" id="password" placeholder="Password" class="form-control"value="<?php echo $decript_password; ?>" />
                                                        </div>
														
                                            </div>
                                         </div>
                                                <div class="form-group">
                                                    <div class="row">
														<div class="col-md-3">
                                                            <label>address: <span class="text-danger">*</span></label>
                                                            <textarea name="address1" id="address1" class="form-control" placeholder="Address" data-parsley-group="information" data-parsley-required><?php echo $address1; ?></textarea>
                                                        </div>
                                                       <div class="col-md-3">
                                                            <label>Mobile:</label>
                                                            <input type="text" name="mobile" id="mobile" placeholder="Mobile" class="form-control" value="<?php echo $mobile; ?>"/>
                                                        </div>
														
                                            </div>
                                         <input type="submit" name="submit" value="Submit" class="btn btn-info">  
                                            </div>
                                        </form>
                                        <!--/ END Form Wizard -->
                                    </div>
                                </section>
                            </div>
                        </div>
                    </div>
		<!--===================================================-->
		<!--End page content-->
	</div>
	<!--===================================================-->
	<!--END CONTENT CONTAINER-->
	<?php include "leftmenu.php"; ?>
</div>
<?php include "footer.php"; ?>
<script src="js/jquery-2.1.1.min.js"></script>
        <!--BootstrapJS [ RECOMMENDED ]-->
        <script src="js/bootstrap.min.js"></script>
		<!--Fast Click [ OPTIONAL ]-->
        <script src="plugins/fast-click/fastclick.min.js"></script>
        <!--Jasmine Admin [ RECOMMENDED ]-->
        <script src="js/scripts.js"></script>
        <!--Switchery [ OPTIONAL ]-->
        <script src="plugins/switchery/switchery.min.js"></script>
        <!--Jquery Steps [ OPTIONAL ]-->
        <script src="plugins/parsley/parsley.min.js"></script>
        <!--Jquery Steps [ OPTIONAL ]-->
        <script src="plugins/jquery-steps/jquery-steps.min.js"></script>
        <!--Bootstrap Select [ OPTIONAL ]-->
        <script src="plugins/bootstrap-select/bootstrap-select.min.js"></script>
        <!--Bootstrap Wizard [ OPTIONAL ]-->
        <script src="plugins/bootstrap-wizard/jquery.bootstrap.wizard.min.js"></script>
        <!--Masked Input [ OPTIONAL ]-->
        <script src="plugins/masked-input/bootstrap-inputmask.min.js"></script>
        <!--Bootstrap Validator [ OPTIONAL ]-->
        <script src="plugins/bootstrap-validator/bootstrapValidator.min.js"></script>
        <!--Fullscreen jQuery [ OPTIONAL ]-->
        <script src="plugins/screenfull/screenfull.js"></script>
        <!--Form Wizard [ SAMPLE ]-->
        <script src="js/demo/wizard.js"></script>
        <!--Demo script [ DEMONSTRATION ]-->
        <script src="js/demo/jasmine.js"></script>
        <!--Form Wizard [ SAMPLE ]-->
        <script src="js/demo/form-wizard.js"></script>
	