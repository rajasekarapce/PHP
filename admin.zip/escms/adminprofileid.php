<?php include "header.php"; 

$fname=isSet($fname) ? $fname : '' ;
$profileid=isSet($profileid) ? $profileid : '' ;
$act = isSet($act) ? $act : '' ; 
$Message = isSet($Message) ? $Message : '' ;

if($submit){
	$profileid = trim(addslashes($profileid));
	$checkStatus = $db->check1column("register","user_access",2);		
	$set  = "profileid = '$profileid'";
	if($checkStatus == 0){
		$set  .= ",fname = 'Amin'";
		$set  .= ",user_access = '2'";
		$set  .= ",active_status = '1'";
		$db->insertrec("insert into register set $set");
		$act = "add";
	}
	else if($checkStatus == 1){
		$db->insertrec("update register set $set where user_access='2'");
		$act = "upd";
	}
	header("location:adminprofileid.php?act=$act");
	exit;
}	
$GetRecord = $db->singlerec("select fname,profileid from register where user_access='2'");
$profileid=$GetRecord['profileid'];
$fname=$GetRecord['fname'];
if($act == "upd")
    $Message = "<font color='green'><b>Updated Successfully</b></font>" ;
else if($act == "add")
    $Message = "<font color='green'><b>Added Successfully</b></font>" ;
?>
<div class="boxed">
	<!--CONTENT CONTAINER-->
	<!--===================================================-->
	<div id="content-container">
		<?php include "header_nav.php"; ?>
		<div class="pageheader">
			<h3><i class="fa fa-home"></i>Admin Profile Id</h3>
			<div class="breadcrumb-wrapper">
				<span class="label">You are here:</span>
				<ol class="breadcrumb">
					<li> <a href="welcome.php"> Home </a> </li>
					<li class="active"> Admin Profile Id</li>
				</ol>
			</div>
		</div>
		<!--Page content-->
		<!--===================================================-->
		<div id="page-content">
			<div class="row">
			  <div class="eq-height">
				 <div class="col-sm-6 eq-box-sm">
					<div class="panel">
						<div class="panel-heading">
							<h3 class="panel-title"><?php echo $Message;?></h3>
						</div>
						<form class="form-horizontal" method="post" action="adminprofileid.php" >
							<div class="panel-body">
								<div class="form-group">
									<label class="col-sm-1 control-label" for="demo-hor-inputemail">Profile ID</label>
									<div class="col-sm-3">
									<input type="text" class="form-control" name="profileid" value="<?php echo $profileid; ?>">
									</div>
								</div>
							</div>
							<div class="panel-footer text-left">
								<div class="row"><div class="col-md-4  text-right"><input class="btn btn-info" type="submit" name="submit" value="Submit"></div></div>
							</div>
						</form>
						<!--===================================================-->
						<!--End Horizontal Form-->
					</div>
				</div>
			  </div>
			</div>
		</div>
		<!--===================================================-->
		<!--End page content-->
	</div>
	<!--===================================================-->
	<!--END CONTENT CONTAINER-->
	<?php include "leftmenu.php"; ?>
</div>
<?php include "footer.php"; ?>