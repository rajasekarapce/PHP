<?php include"header.php"; ?>
<div class="boxed">
	<!--CONTENT CONTAINER-->
	<!--===================================================-->
	<div id="content-container">
		<?php include "header_nav.php"; ?>
		<div class="pageheader">
			<h3><i class="fa fa-home"></i>membership </h3>
			<div class="breadcrumb-wrapper">
				<span class="label">You are here:</span>
				<ol class="breadcrumb">
					<li> <a href="welcome.php"> Home </a> </li>
					<li class="active"> membership </li>
				</ol>
			</div>
		</div>
<?php
$upd = isset($upd)?$upd:'';
$id = isSet($id) ? $id : '' ;
$Message = isSet($Message) ? $Message : '' ;
$name = isSet($name) ? $name : '' ;


if($submit) {
    $crcdt = time();
	$name = trim(addslashes($name));
		$checkStatus = $db->check1column("membership","name",$name);
		if($upd == 2)
			$checkStatus = 0;

		if($checkStatus == 0){
			$set  = "name = '$name'";
			if($upd == 1){
				$set  .= ",active_status = '1'";
				$db->insertrec("insert into membership set $set");
				$act = "add";
			}
			else if($upd == 2){
				$db->insertrec("update membership set $set where id='$idvalue'");
				$act = "upd";
			}
			header("location:membership.php?act=$act");
			exit;
		}	
		 else {
			 $id = $idvalue;
			$Message = "<font color='red'>$name Already Exit's</font>";
		}
	}
if($upd == 1)
	$TextChange = "Add";
else if($upd == 2)
	$TextChange = "Edit";

$GetRecord = $db->singlerec("select * from membership where id='$id'");
@extract($GetRecord);
$name = stripslashes($name);
?>
		<!--Page content-->
		<!--===================================================-->
		<div id="page-content">
			<div class="row">
			  <div class="eq-height">
				 <div class="col-sm-6 eq-box-sm">
					<div class="panel">
						<div class="panel-heading">
							<h3 class="panel-title"><?php echo $TextChange;?> membership</h3>
						</div>
						<form class="form-horizontal" method="post" action="membershipupd.php" enctype="multipart/form-data">
							<input type="hidden" name="idvalue" value="<?php echo $id;?>" />
							<input type="hidden" name="upd" value="<?php echo $upd;?>" />							
							<div class="panel-body">
								<table style="padding:25px;">
									<tr>
										<td>Name <font color="red">*</font></td>
										<td><input type="text" name="name" id="name" value="<?php echo $name; ?>" class="form-control">
										</td>
									</tr>
								</table>
							</div>
							<div class="panel-footer text-left">
								<div class="col-md-4  text-right"><input class="btn btn-info" type="submit" name="submit" value="Submit"></div>
								<a class="btn btn-info" href="membership.php">Cancel</a>
							</div>
						</form>
						<!--===================================================-->
						<!--End Horizontal Form-->
					</div>
				</div>
			  </div>
			</div>
		</div>
		<!--===================================================-->
		<!--End page content-->
	</div>
	<!--===================================================-->
	<!--END CONTENT CONTAINER-->
	<?php include "leftmenu.php"; ?>
</div>
<?php include "footer.php"; ?>