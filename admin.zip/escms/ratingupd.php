<?php include "header.php"; 

$upd = isset($upd)?$upd:'';
$id = isSet($id) ? $id : '' ;
$act  = isSet($act) ? $act : '' ;
$page  = isSet($page) ? $page : '' ;
$rid=isSet($rid) ? $rid : '' ;
$Message  = isSet($Message) ? $Message : '' ;
$UserName=isSet($UserName) ? $UserName : '' ;
$points=isSet($points) ? $points : '' ;
$Descripstion=isSet($Descripstion) ? $Descripstion : '' ;

if($submit){
	$crcdt = date("Y-m-d");
	$UserName=trim(addslashes($UserName));
	$points=trim(addslashes($points));
	$Descripstion=trim(addslashes($Descripstion));
	$set  = "crcdt = '$crcdt'";
	$set  .= ",UserName = '$UserName'";
	$set  .= ",points = '$points'";
	$set  .= ",Descripstion = '$Descripstion'";
	$set  .= ",ProductId = '$ridvalue'";
	
	if($upd == 1){
		$idvalue=$db->insertid("insert into rating set $set");
		$act = "add";
	}
	else if($upd == 2){
		$db->insertrec("update rating set $set where id='$idvalue'");
		$act = "upd";
	}
	echo "<script>location.href='rating.php?rid=$ridvalue&act=$act';</script>";
	header("location:rating.php?rid=$ridvalue&act=$act");
	exit;	
}
		
$GetRecord = $db->singlerec("select * from rating where id='$id'");
@extract($GetRecord);
?>
<script src="//tinymce.cachefly.net/4.1/tinymce.min.js"></script>
<script type="text/javascript" src="js/tinymce.js" ></script>
<script src="js/product.js" type="text/javascript"></script>
<div class="boxed">
	<!--CONTENT CONTAINER-->
	<!--===================================================-->
	<div id="content-container">
		<?php include "header_nav.php"; ?>
		<div class="pageheader">
			<h3><i class="fa fa-users"></i>Rating </h3>
			<div class="breadcrumb-wrapper">
				<span class="label">You are here:</span>
				<ol class="breadcrumb">
					<li> <a href="welcome.php"> Home </a> </li>
					<li class="active"> Rating </li>
				</ol>
			</div>
		</div>
		<!--Page content-->
		<!--===================================================-->
		<div id="page-content">
            <div class="row">
                <div class="col-md-12">
                    <section class="panel">
                        <div class="panel-heading">
                            <h3 class="panel-title">Rating <?php echo $Message;?></h3>
                         </div>
                         <div class="panel-body">
                         <!-- START Form Wizard -->
                        <form class="form-horizontal form-bordered" action="ratingupd.php"  enctype="multipart/form-data" method="POST">
						<input type="hidden" name="upd" value="<?php echo $upd;?>">
						<input type="hidden" name="idvalue" value="<?php echo $id;?>">
						<input type="hidden" name="ridvalue" value="<?php echo $rid;?>">
								<div class="form-group">
									<label class="col-sm-2 control-label"> UserName : </label>
									<div class="col-sm-6">
										<input type="text" name="UserName" id="UserName" value="<?php echo $UserName; ?>"class="form-control" data-parsley-group="order" data-parsley-required />
									</div>
								</div>
								<div class="form-group">
									<label class="col-sm-2 control-label"> Rating : </label>
									<div class="col-sm-6">
										<input type="text" name="points" value="<?php echo $points; ?>"class="form-control" data-parsley-group="order" data-parsley-required />
									</div>
								</div>
								<div class="form-group">
									<label class="col-sm-2 control-label"> Descripstion : </label>
									<div class="col-sm-6">
										<textarea name="Descripstion" id="Descripstion" class="form-control" /><?php echo $Descripstion; ?></textarea> 
									</div>
								</div>
								<div class="form-group">
									<div class="col-sm-6">
										<input type="submit" name="submit" value="submit" class="btn btn-primary">
									</div>
								</div>
							<!--/ Wizard Container 1 -->
						</form>
						<!--/ END Form Wizard -->
					</div>
				</section>
			</div>
		</div>
	</div>
		<!--===================================================-->
		<!--End page content-->
	</div>
	<!--===================================================-->
	<!--END CONTENT CONTAINER-->
	<?php include "leftmenu.php"; ?>
</div>
<?php include "footer.php"; ?>