<?php include "header.php"; ?>
            <!--===================================================-->
            <!--END NAVBAR-->
            <div class="boxed">
                <!--CONTENT CONTAINER-->
                <!--===================================================-->
                <div id="content-container">
                    <?php include "header_nav.php"; ?>
                    <div class="pageheader">
                        <h3><i class="fa fa-home"></i> Slider </h3>
                        <div class="breadcrumb-wrapper">
                            <span class="label">You are here:</span>
                            <ol class="breadcrumb">
                                <li> <a href="welcome.php"> Home </a> </li>
                                <li class="active">Slider </li>
                            </ol>
                        </div>
                    </div>
<?php
$idvalue = isSet($idvalue) ? $idvalue : '' ;
$page = isSet($page) ? $page : '' ;
$slider_title = isSet($slider_title) ? $slider_title : '' ;
$slider_descripstion = isSet($slider_descripstion) ? $slider_descripstion : '' ;
$img = isset($img)? $img: '';
$usercre = isSet($usercre) ? $usercre : '' ;

$GetRecordView = $db->singlerec("select * from slider where id='$id'");
@extract($GetRecordView);
$GetRefereBy = $db->get_all("select * from slider where id='$id'");
@extract($GetRefereBy);
?>
                   <!--Page content-->
                    <!--===================================================-->
                    <div id="page-content">
                        <!-- Basic Data Tables -->
                        <!--===================================================-->
						<h3>View slider Details</h3><a href="slider.php"  class="btn btn-success">Back</a></br>
                        <div class="panel">
                            <div class="panel-heading">
                            </div>
                            <div class="panel-body">
								<table>
                                    <thead>
                                        <tr>
											<td>Slider Title</td><td width="75">:</td><td><?php echo $slider_title;?></td>
											</tr>
											<tr>
											<td>Image</td><td width="75">:</td><td><img src="uploads\slider\<?php echo $img; ?>" width="50" height="50"></td>
											</tr>
											<tr>
											<td>Slider Descripstion</td><td width="75">:</td><td><?php echo $slider_title;?></td>
                                       </tr>
                                    </thead>
                                </table>
                            </div>
                        </div>
                    </div>
                    <!--===================================================-->
                    <!--End page content-->
                </div>
                <!--===================================================-->
                <!--END CONTENT CONTAINER-->
			<?php include "leftmenu.php"; ?>	
            </div>
<?php

include "footer.php";
?>