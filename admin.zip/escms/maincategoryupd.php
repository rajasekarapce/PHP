<?php include"header.php"; ?>
<div class="boxed">
	<!--CONTENT CONTAINER-->
	<!--===================================================-->
	<div id="content-container">
		<?php include "header_nav.php"; ?>
		<div class="pageheader">
			<h3><i class="fa fa-home"></i>Category </h3>
			<div class="breadcrumb-wrapper">
				<span class="label">You are here:</span>
				<ol class="breadcrumb">
					<li> <a href="welcome.php"> Home </a> </li>
					<li class="active"> Category </li>
				</ol>
			</div>
		</div>
<?php
$upd = isset($upd)?$upd:'';
$id = isSet($id) ? $id : '' ;
$Message = isSet($Message) ? $Message : '' ;
$name=isSet($name)?$name:'';
$catid=isSet($catid)?$catid:'';
$cat_id = isset($cat_id)?$cat_id:'';

if($submit) {
    $crcdt = time();
	$name = trim(addslashes($name));
		$checkStatus = $db->check1column("maincategory","name",$name);
		if($upd == 2)
			$checkStatus = 0;

		if($checkStatus == 0){
			$set  = "name = '$name'";
			$set  .= ",shortname = '$shortname'";
			$set  .= ",ordered = '$ordered'";
			if($upd == 1){
				$set  .= ",crcdt = '$crcdt'";    
				$set  .= ",active_status = '1'";
				$set  .= ",usercre = '$usrcre_name'";
				$idvalue=$db->insertid("insert into maincategory set $set");
				$act = "add";
			}
			else if($upd == 2){
				$set  .= ",chngdt = '$crcdt'";    
				$set  .= ",userchng = '$usrcre_name'";
				$db->insertrec("update maincategory set $set where id='$idvalue'");
				$act = "upd";
			}
			if($_FILES['catimg']['tmp_name'] != "" || $_FILES['catimg']['tmp_name'] != null){
				$fpath = $_FILES['catimg']['tmp_name'] ;
				$fname = $_FILES['catimg']['name'] ;
				$getext = substr(strrchr($fname, '.'), 1);
				$ext = strtolower($getext);
				if($ext=='jpg' || $ext=='jpeg' || $ext=='png' || $ext=='jpeg' || $ext=='gif' || $ext=='bmp'){
					$getrec1=$db->singlerec("select catimg from maincategory where id='$idvalue'");
					$prdimg=$getrec1['catimg'];
					if($prdimg !="noimages.jpg"){@unlink("../uploads/catimg/$catimg");}
					$NgImg = $idvalue.".".$ext;
					$img_org = "../uploads/catimg/$NgImg";	
					move_uploaded_file($fpath,$img_org);
					$db->insertrec("update maincategory set catimg='$NgImg' where id='$idvalue';");
				}
				else{
				echo "<center style='color:red;'>jpg or png file will only accepted..</center>";
				}
			}
			header("location:maincategory.php?act=$act");
			exit;
		}	
		 else {
			 $id = $idvalue;
			$Message = "<font color='red'>$name Already Exit's</font>";
		}
	}
if($upd == 1)
	$TextChange = "Add";
else if($upd == 2)
	$TextChange = "Edit";

$GetRecord = $db->singlerec("select * from maincategory where id='$id'");
@extract($GetRecord);
if($cat_id !=0)
	$catid=$cat_id;
?>
		<!--Page content-->
		<!--===================================================-->
		<div id="page-content">
			<div class="row">
			  <div class="eq-height">
				 <div class="col-sm-6 eq-box-sm">
					<div class="panel">
						<div class="panel-heading">
							<h3 class="panel-title"><?php echo $TextChange;?> Category</h3>
						</div>
						<form class="form-horizontal" method="post" action="maincategoryupd.php" enctype="multipart/form-data">
							<input type="hidden" name="idvalue" value="<?php echo $id;?>" />
							<input type="hidden" name="upd" value="<?php echo $upd;?>" />							
							<div class="panel-body">
								<table style="padding:25px;">
									<tr>
										<td>Name <font color="red">*</font></td>
										<td><input type="text" name="name" id="name" value="<?php echo $name; ?>" class="form-control">
										</td>
									</tr>
									<tr>
										<td>Short Name <font color="red">*</font></td>
										<td><input type="text" name="shortname" value="<?php echo $shortname; ?>" class="form-control">
										</td>
									</tr>
									<tr>
										<td>Order By<font color="red">*</font></td>
										<td><input type="text" name="ordered" value="<?php echo $ordered; ?>" class="form-control">
										</td>
									</tr>
									
									<tr>
										<td>Image <font color="red">*</font></td>
										<td><img src="../uploads/catimg/<?php echo $catimg;?>"><br/>
										<input type="file" name="catimg" class="form-control">
										</td>
									</tr>
								</table>
							</div>
							<div class="panel-footer text-left">
								<div class="col-md-4  text-right"><input class="btn btn-info" type="submit" name="submit" value="Submit"></div>
								<a class="btn btn-info" href="maincategory.php">Cancel</a>
							</div>
						</form>
						<!--===================================================-->
						<!--End Horizontal Form-->
					</div>
				</div>
			  </div>
			</div>
		</div>
		<!--===================================================-->
		<!--End page content-->
	</div>
	<!--===================================================-->
	<!--END CONTENT CONTAINER-->
	<?php include "leftmenu.php"; ?>
</div>
<?php include "footer.php"; ?>