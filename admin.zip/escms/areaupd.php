<?php include"header.php"; ?>
<div class="boxed">
	<!--CONTENT CONTAINER-->
	<!--===================================================-->
	<div id="content-container">
		<?php include "header_nav.php"; ?>
		<div class="pageheader">
			<h3><i class="fa fa-home"></i>Area </h3>
			<div class="breadcrumb-wrapper">
				<span class="label">You are here:</span>
				<ol class="breadcrumb">
					<li> <a href="welcome.php"> Home </a> </li>
					<li class="active"> Area </li>
				</ol>
			</div>
		</div>
		
<?php
$upd = isset($upd)?$upd:'';
$sid = isSet($sid) ? $sid : '' ;
$cid = isSet($cid) ? $cid : '' ;
$city_auto_id = isSet($city_auto_id) ? $city_auto_id : '' ;
$area_auto_id = isSet($area_auto_id) ? $area_auto_id : '' ;
$act  = isSet($act) ? $act : '' ;
$page  = isSet($page) ? $page : '' ;
$Message  = isSet($Message) ? $Message : '' ;
$area_name = isSet($area_name) ? $area_name : '' ;

if($submit) {
    $crcdt = time();
    $area_name  = trim(addslashes($area_name));
	$checkStatus = $db->check1column("area","area_name",$area_name);
	if($area_name != ''){
		if($upd == 2)
			$checkStatus = 0;
			
		if($checkStatus == 0){
			$set  = "area_name = '$area_name'";
			if($upd == 1){
				$set  .= ",crcdt = '$crcdt'";    
				$set  .= ",active_status = '1'";
				$set  .= ",state_auto_id = '$sid'";
				$set  .= ",country_auto_id = '$cid'";
				$set  .= ",city_auto_id = '$city_auto_id'";
				$db->insertrec("insert into area set $set");
				$act = "add";
			}
			else if($upd == 2){
				$set  .= ",chngdt = '$crcdt'";
				$db->insertrec("update area set $set where area_auto_id='$area_auto_id'");
				$act = "upd";
			}
			header("location:area.php?&cid=$cid&sid=$sid&city_auto_id=$city_auto_id");
			exit;
			}
			else{
			$upd = $upd ;
			$Message = "<font color='red'>$area_name Already Exit</font>";
		}
    } 
	else{
		$upd = $upd ;
		$Message = "<font color='red'>Input Fields Marked With * are compulsory</font>";
	}
}
if($upd==1){
	$TextChange = "Add";
}
else if($upd==2){
	$TextChange = "Update";
	$Getmaincat=$db->singlerec("select * from area where state_auto_id='$sid'");
    $area_name = stripslashes($Getmaincat['area_name']);
}

?>
		
			<!--Page content-->
		<!--===================================================-->
		<div id="page-content">
			<div class="row">
			  <div class="eq-height">
				 <div class="col-sm-6 eq-box-sm">
					<div class="panel">
						<div class="panel-heading">
							<h3 class="panel-title"><?php echo $TextChange;?> Area</h3>
						</div>
						<form class="form-horizontal" method="post" action="">
							<input type="hidden" name="idvalue" value="<?php echo $area_auto_id;?>" />
							<input type="hidden" name="upd" value="<?php echo $upd;?>" />							
							<div class="panel-body">
								<table style="padding:25px;">
									<tr>
										<td>Name <font color="red">*</font></td>
										<td><input type="text" name="area_name" id="area_name" value="<?php echo $area_name; ?>" class="form-control">
										</td>
									</tr>
							    </table>
							</div>
							<div class="panel-footer text-left">
								<div class="col-md-4  text-right"><input class="btn btn-info" type="submit" name="submit" value="Submit"></div>
								<a class="btn btn-info" href="area.php?cid=<?php echo $cid; ?>&sid=<?php echo $sid; ?>">Cancel</a>
							</div>
						</form>
						<!--===================================================-->
						<!--End Horizontal Form-->
					</div>
				</div>
			  </div>
			</div>
		</div>
		<!--===================================================-->
		<!--End page content-->
	</div>
	<!--===================================================-->
	<!--END CONTENT CONTAINER-->
	<?php include "leftmenu.php"; ?>
</div>
<?php include "footer.php"; ?>