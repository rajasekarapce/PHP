<?php include "header.php"; ?>
            <!--===================================================-->
            <!--END NAVBAR-->
            <div class="boxed">
                <!--CONTENT CONTAINER-->
                <!--===================================================-->
                <div id="content-container">
                    <?php include "header_nav.php"; ?>
                    <div class="pageheader">
                        <h3><i class="fa fa-home"></i> State </h3>
                        <div class="breadcrumb-wrapper">
                            <span class="label">You are here:</span>
                            <ol class="breadcrumb">
                                <li> <a href="welcome.php"> Home </a> </li>
                                <li class="active">State </li>
                            </ol>
                        </div>
                    </div>
<?php
$idvalue = isSet($idvalue) ? $idvalue : '' ;
$page = isSet($page) ? $page : '' ;
$state_name = isSet($state_name) ? $state_name : '' ;
$crcdt=date("Y.m.d");
$GetRecordView = $db->singlerec("select * from state where country_auto_id='$cid'");
@extract($GetRecordView);
$GetRefereBy = $db->get_all("select * from state where country_auto_id='$cid'");
@extract($GetRefereBy);
?>
       <!--Page content-->
                    <!--===================================================-->
                    <div id="page-content">
                        <!-- Basic Data Tables -->
                        <!--===================================================-->
						<h3>View State Details</h3><a href="state.php?cid=<?php echo $cid; ?>"  class="btn btn-success">Back</a></br>
                        <div class="panel">
                            <div class="panel-heading">
                            </div>
                            <div class="panel-body">
								<table>
                                    <thead>
                                        <tr>
											<td>Name</td><td width="75">:</td><td><?php echo $state_name;?></td>
										</tr>
										<tr>
											<td>Created</td><td width="75">:</td><td><?php echo $crcdt=date("Y.m.d"); ?></td>
										</tr>
                                    </thead>
                                </table>
                            </div>
                        </div>
                    </div>
                    <!--===================================================-->
                    <!--End page content-->
                </div>
                <!--===================================================-->
                <!--END CONTENT CONTAINER-->
			<?php include "leftmenu.php"; ?>	
            </div>
<?php

include "footer.php";
?>