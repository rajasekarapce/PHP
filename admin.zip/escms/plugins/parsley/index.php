<?php
echo "<script>location.href='../index.php';</script>";
header("Location:../index.php"); exit;
?>