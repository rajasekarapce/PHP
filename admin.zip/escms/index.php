<?php	echo "<script>location.href='login.php';</script>"; 
	header("Location:login.php");
	exit;
?>