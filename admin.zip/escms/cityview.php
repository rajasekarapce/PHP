<?php include "header.php"; ?>
            <!--===================================================-->
            <!--END NAVBAR-->
            <div class="boxed">
                <!--CONTENT CONTAINER-->
                <!--===================================================-->
                <div id="content-container">
                    <?php include "header_nav.php"; ?>
                    <div class="pageheader">
                        <h3><i class="fa fa-home"></i> City </h3>
                        <div class="breadcrumb-wrapper">
                            <span class="label">You are here:</span>
                            <ol class="breadcrumb">
                                <li> <a href="welcome.php"> Home </a> </li>
                                <li class="active">City </li>
                            </ol>
                        </div>
                    </div>
<?php
$cid = isSet($cid) ? $cid : '' ;
$sid = isSet($sid) ? $sid : '' ;
$page = isSet($page) ? $page : '' ;
$city_auto_id = isSet($city_auto_id) ? $city_auto_id : '' ;
$city_name = isSet($city_name) ? $city_name : '' ;
$crcdt=date("Y.m.d");
$GetRecordView = $db->singlerec("select * from city where city_auto_id='$city_auto_id'");
@extract($GetRecordView);
$GetRefereBy = $db->get_all("select * from city where city_auto_id='$city_auto_id'");
@extract($GetRefereBy);
?>
       <!--Page content-->
                    <!--===================================================-->
                    <div id="page-content">
                        <!-- Basic Data Tables -->
                        <!--===================================================-->
						<h3>View City Details</h3><a href="city.php?city_auto_id=<?php echo $city_auto_id; ?>&cid=<?php echo $cid; ?>&sid=<?php echo $sid; ?>"  class="btn btn-success">Back</a></br>
                        <div class="panel">
                            <div class="panel-heading">
                            </div>
                            <div class="panel-body">
								<table>
                                    <thead>
                                        <tr>
											<td>Name</td><td width="75">:</td><td><?php echo $city_name;?></td>
										</tr>
										<tr>
											<td>Created</td><td width="75">:</td><td><?php echo $crcdt=date("Y.m.d"); ?></td>
										</tr>
                                    </thead>
                                </table>
                            </div>
                        </div>
                    </div>
                    <!--===================================================-->
                    <!--End page content-->
                </div>
                <!--===================================================-->
                <!--END CONTENT CONTAINER-->
			<?php include "leftmenu.php"; ?>	
            </div>
<?php

include "footer.php";
?>