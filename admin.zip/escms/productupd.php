<?php include "header.php"; 

$upd = isset($upd)?$upd:'';
$id = isSet($id) ? $id : '' ;
$act  = isSet($act) ? $act : '' ;
$page  = isSet($page) ? $page : '' ;
$Message  = isSet($Message) ? $Message : '' ;
$prod_keyword=isSet($prod_keyword) ? $prod_keyword: '' ;
$mutikeywords=isSet($mutikeywords) ? $mutikeywords: '' ;
$prod_cat=isSet($prod_cat) ? $prod_cat : '' ;
$prod_name=isSet($prod_name) ? $prod_name : '' ;
$prod_catid=isSet($prod_catid) ? $prod_catid : '' ;
$prod_cateid=isSet($prod_cateid) ? $prod_cateid : '' ;
$short_prod_details=isSet($short_prod_details) ? $short_prod_details : '' ;
$prod_details=isSet($prod_details) ? $prod_details : '' ;
$prod_minprice=isSet($prod_minprice) ? $prod_minprice : '' ;
$prod_maxprice=isSet($prod_maxprice) ? $prod_maxprice : '' ;
$saletype=isSet($saletype) ? $saletype : '' ;
$max_supply_quantity=isSet($max_supply_quantity) ? $max_supply_quantity :'';
$additionalinfo=isSet($additionalinfo) ? $additionalinfo : '' ;
$userurl=isSet($userurl) ? $userurl : '' ;
$adminurl=isSet($adminurl) ? $adminurl : '' ;

if($submit){
	$crcdt = date("Y-m-d");
	$prod_name=trim(addslashes($prod_name));
	$short_prod_details=trim(addslashes($short_prod_details));
	$prod_details=trim(addslashes($prod_details));
	$prod_minprice=trim(addslashes($prod_minprice));
	$prod_maxprice=trim(addslashes($prod_maxprice));
	$prod_keyword=trim(addslashes($prod_keyword));
	$mutikeywords=trim(addslashes($mutikeywords));
	$additionalinfo=(addslashes($additionalinfo));
	$userurl=(addslashes($userurl));
	$adminurl=(addslashes($adminurl));
	$getrec1=$db->singlerec("select name from maincategory where id='$prod_catid'"); $prod_cat=$getrec1['name'];
	$getrec2=$db->singlerec("select name from category where id='$prod_cateid'");	$prod_cate=$getrec2['name'];
	$getrec3=$db->singlerec("select name from category where id='$prod_subcatid'"); $prod_subcate=$getrec3['name'];
	$set  = "prod_name = '$prod_name'";
	$set  .= ",prod_catid = '$prod_catid'";
	$set  .= ",prod_cateid = '$prod_cateid'";
	$set  .= ",prod_subcatid = '$prod_subcatid'";
	$set  .= ",prod_cat = '$prod_cat'";
	$set  .= ",prod_cate = '$prod_cate'";
	$set  .= ",prod_subcate = '$prod_subcate'";
	$set  .= ",short_prod_details = '$short_prod_details'";
	$set  .= ",prod_details = '$prod_details'";
	$set  .= ",prod_quantitytype = '$prod_quantitytype'";
	$set  .= ",max_supply_quantity = '$max_supply_quantity'";
	$set  .= ",prod_minquantity = '$prod_minquantity'";
	$set  .= ",prod_minprice = '$prod_minprice'";
	$set  .= ",prod_maxprice = '$prod_maxprice'";
	$set  .= ",saletype = '$saletype'";
	$set  .= ",additionalinfo = '$additionalinfo'";
	$set  .= ",userurl = '$userurl'";
	$set  .= ",adminurl = '$adminurl'";
	$set  .= ",prod_keyword = '$prod_keyword'";
	$set  .= ",mutikeywords = '$mutikeywords'";
	
	if($upd == 1){
		$set  .= ",prod_crtdate = '$crcdt'";
		$set  .= ",prod_status = '1'";
		$idvalue=$db->insertid("insert into product set $set");
		$act = "add";
	}
	else if($upd == 2){
		$db->insertrec("update product set $set where id='$idvalue'");
		$act = "upd";
	}
	if($_FILES['prodimg']['tmp_name'] != "" || $_FILES['prodimg']['tmp_name'] != null){
		$fpath = $_FILES['prodimg']['tmp_name'] ;
		$fname = $_FILES['prodimg']['name'] ;
		$getext = substr(strrchr($fname, '.'), 1);
		$ext = strtolower($getext);
		if($ext=='jpg' || $ext=='jpeg' || $ext=='png' || $ext=='jpeg' || $ext=='gif' || $ext=='bmp'){
			$NgImg = $idvalue.".".$ext;
			$img_org = "../uploads/prodimg/$NgImg";	
			$img_size = "../uploads/prodimg/400x400/$NgImg";
			$img_thum = "../uploads/prodimg/40x40/$NgImg";
			move_uploaded_file($fpath,$img_org);
			//move_uploaded_file($fpath,$img_size);
			//move_uploaded_file($fpath,$img_thum);
			$resizeObj = new resize($img_org);			
			$resizeObj -> resizeImage(400, 400, 'exact');
			$resizeObj -> saveImage($img_size, 72);
			$resizeObj -> resizeImage(40, 40, 'exact');
			$resizeObj -> saveImage($img_thum, 72);
			@unlink($img_org);
			$db->insertrec("update product set prodimg='$NgImg' where id='$idvalue';");
			echo "<script>location.href='product.php?act=add';</script>";
			header("location:product.php?act=add");
			exit;
		}
		else{
		echo "<center style='color:red;'>jpg or png or gif file will only accepted..</center>";
		}
	}
	//image 1
	if($_FILES['prodimg']['tmp_name'] != "" || $_FILES['prodimg']['tmp_name'] != null){
		$fpath = $_FILES['prodimg']['tmp_name'] ;
		$fname = $_FILES['prodimg']['name'] ;
		$image_info = getimagesize($_FILES["prodimg"]["tmp_name"]);
		$image_width = $image_info[0];
		$image_height = $image_info[1];
		$size=filesize($_FILES['prodimg']['tmp_name']);
		$getext = substr(strrchr($fname, '.'), 1);
		$ext = strtolower($getext);
		if($size>1048576) { //1048576 Bytes =  MB
			echo "<br/><center style='color:red;'>Too big! image size should be lesser then 1 MB</center>"; 
			echo "<script>var goback = setTimeout(function(){window.history.back();},5000);</script>";	
			exit;
		}
		if($image_width<400 || $image_height<400) { 
			echo "<br/><center style='color:red;'>Too small! You are upload ($image_width x $image_height) image. it must be (300 x 300) or grater..</center>"; 
			echo "<script>var goback = setTimeout(function(){window.history.back();},5000);</script>";	
			exit;
		}
		/* if($image_width!=$image_height) { 
			echo "<br/><center style='color:red;'>Invalid aspect ratio! Product image aspect ratio must be 1:1.<br/> Image must be (300 x 300) or grater.. </center>"; 
			echo "<script>var goback = setTimeout(function(){window.history.back();},5000);</script>";	
			exit;
		} */		
		echo "".$ext; die;
		if($ext=='jpg' || $ext=='jpeg' || $ext=='png' || $ext=='jpeg' || $ext=='gif' || $ext=='bmp'){
			$getrec1=$db->singlerec("select prodimg from product where id='$idvalue'");
			$prdimg=$getrec1['prodimg'];
			if($prdimg !="noimages.jpg"){@unlink("../uploads/prodimg/40x40/$prdimg");@unlink("../uploads/prodimg/400x400/$prdimg");}
			$NgImg = $idvalue.".".$ext;
			$img_org = "../uploads/prodimg/$NgImg";	
			$img_size = "../uploads/prodimg/400x400/$NgImg";
			$img_thum = "../uploads/prodimg/40x40/$NgImg";
			move_uploaded_file($fpath,$img_org);
			$resizeObj = new resize($img_org);			
			$resizeObj -> resizeImage(400, 400, 'exact');
			$resizeObj -> saveImage($img_size, 72);
			$resizeObj -> resizeImage(40, 40, 'exact');
			$resizeObj -> saveImage($img_thum, 72);
			@unlink($img_org);
			$db->insertrec("update product set prodimg='$NgImg' where id='$idvalue';");
		}
		else{
		echo "<center style='color:red;'>jpg or png file will only accepted..</center>";
		}
	}
	//image 2
	if($_FILES['prodimg2']['tmp_name'] != "" || $_FILES['prodimg2']['tmp_name'] != null){
		$fpath = $_FILES['prodimg2']['tmp_name'] ;
		$fname = $_FILES['prodimg2']['name'] ;
		$image_info = getimagesize($_FILES["prodimg2"]["tmp_name"]);
		$image_width = $image_info[0];
		$image_height = $image_info[1];
		$size=filesize($_FILES['prodimg2']['tmp_name']);
		$getext = substr(strrchr($fname, '.'), 1);
		$ext = strtolower($getext);
		if($size>1048576) { //1048576 Bytes =  MB
			echo "<br/><center style='color:red;'>Too big! image size should be lesser then 1 MB</center>"; 
			echo "<script>var goback = setTimeout(function(){window.history.back();},5000);</script>";	
			exit;
		}
		if($image_width<400 || $image_height<400) { 
			echo "<br/><center style='color:red;'>Too small! You are upload ($image_width x $image_height) image. it must be (300 x 300) or grater..</center>"; 
			echo "<script>var goback = setTimeout(function(){window.history.back();},5000);</script>";	
			exit;
		}
		/* if($image_width!=$image_height) { 
			echo "<br/><center style='color:red;'>Invalid aspect ratio! Product image aspect ratio must be 1:1.<br/> Image must be (300 x 300) or grater.. </center>"; 
			echo "<script>var goback = setTimeout(function(){window.history.back();},5000);</script>";	
			exit;
		} */		
		if($ext=='jpg' || $ext=='jpeg' || $ext=='png' || $ext=='jpeg' || $ext=='gif' || $ext=='bmp'){
			$getrec1=$db->singlerec("select prodimg2 from product where id='$idvalue'");
			$prdimg2=$getrec1['prodimg2'];
			if($prdimg2 !="noimages.jpg"){@unlink("../uploads/prodimg/40x40/$prdimg2");@unlink("../uploads/prodimg/400x400/$prdimg2");}
			$NgImg = $idvalue."2".".".$ext;
			$img_org = "../uploads/prodimg/$NgImg";	
			$img_size = "../uploads/prodimg/400x400/$NgImg";
			$img_thum = "../uploads/prodimg/40x40/$NgImg";
			move_uploaded_file($fpath,$img_org);
			$resizeObj = new resize($img_org);			
			$resizeObj -> resizeImage(400, 400, 'exact');
			$resizeObj -> saveImage($img_size, 72);
			$resizeObj -> resizeImage(40, 40, 'exact');
			$resizeObj -> saveImage($img_thum, 72);
			@unlink($img_org);
			$db->insertrec("update product set prodimg2='$NgImg' where id='$idvalue';");
		}
		else{
		echo "<center style='color:red;'>jpg or png file will only accepted..</center>";
		}
	}
	//image 3
if($_FILES['prodimg3']['tmp_name'] != "" || $_FILES['prodimg3']['tmp_name'] != null){
		$fpath = $_FILES['prodimg3']['tmp_name'] ;
		$fname = $_FILES['prodimg3']['name'] ;
		$image_info = getimagesize($_FILES["prodimg3"]["tmp_name"]);
		$image_width = $image_info[0];
		$image_height = $image_info[1];
		$size=filesize($_FILES['prodimg3']['tmp_name']);
		$getext = substr(strrchr($fname, '.'), 1);
		$ext = strtolower($getext);
		if($size>1048576) { //1048576 Bytes =  MB
			echo "<br/><center style='color:red;'>Too big! image size should be lesser then 1 MB</center>"; 
			echo "<script>var goback = setTimeout(function(){window.history.back();},5000);</script>";	
			exit;
		}
		if($image_width<400 || $image_height<400) { 
			echo "<br/><center style='color:red;'>Too small! You are upload ($image_width x $image_height) image. it must be (300 x 300) or grater..</center>"; 
			echo "<script>var goback = setTimeout(function(){window.history.back();},5000);</script>";	
			exit;
		}
		/* if($image_width!=$image_height) { 
			echo "<br/><center style='color:red;'>Invalid aspect ratio! Product image aspect ratio must be 1:1.<br/> Image must be (300 x 300) or grater.. </center>"; 
			echo "<script>var goback = setTimeout(function(){window.history.back();},5000);</script>";	
			exit;
		} */		
		if($ext=='jpg' || $ext=='jpeg' || $ext=='png' || $ext=='jpeg' || $ext=='gif' || $ext=='bmp'){
			$getrec1=$db->singlerec("select prodimg3 from product where id='$idvalue'");
			$prdimg3=$getrec1['prodimg3'];
			if($prdimg3 !="noimages.jpg"){@unlink("../uploads/prodimg/40x40/$prdimg3");@unlink("../uploads/prodimg/400x400/$prdimg3");}
			$NgImg = $idvalue."3".".".$ext;
			$img_org = "../uploads/prodimg/$NgImg";	
			$img_size = "../uploads/prodimg/400x400/$NgImg";
			$img_thum = "../uploads/prodimg/40x40/$NgImg";
			move_uploaded_file($fpath,$img_org);
			$resizeObj = new resize($img_org);			
			$resizeObj -> resizeImage(400, 400, 'exact');
			$resizeObj -> saveImage($img_size, 72);
			$resizeObj -> resizeImage(40, 40, 'exact');
			$resizeObj -> saveImage($img_thum, 72);
			@unlink($img_org);
			$db->insertrec("update product set prodimg3='$NgImg' where id='$idvalue';");
		}
		else{
		echo "<center style='color:red;'>jpg or png file will only accepted..</center>";
		}
	}
	//image 4
	if($_FILES['prodimg4']['tmp_name'] != "" || $_FILES['prodimg4']['tmp_name'] != null){
		$fpath = $_FILES['prodimg4']['tmp_name'] ;
		$fname = $_FILES['prodimg4']['name'] ;
		$image_info = getimagesize($_FILES["prodimg4"]["tmp_name"]);
		$image_width = $image_info[0];
		$image_height = $image_info[1];
		$size=filesize($_FILES['prodimg4']['tmp_name']);
		$getext = substr(strrchr($fname, '.'), 1);
		$ext = strtolower($getext);
		if($size>1048576) { //1048576 Bytes =  MB
			echo "<br/><center style='color:red;'>Too big! image size should be lesser then 1 MB</center>"; 
			echo "<script>var goback = setTimeout(function(){window.history.back();},5000);</script>";	
			exit;
		}
		if($image_width<400 || $image_height<400) { 
			echo "<br/><center style='color:red;'>Too small! You are upload ($image_width x $image_height) image. it must be (300 x 300) or grater..</center>"; 
			echo "<script>var goback = setTimeout(function(){window.history.back();},5000);</script>";	
			exit;
		}
/* 		if($image_width!=$image_height) { 
			echo "<br/><center style='color:red;'>Invalid aspect ratio! Product image aspect ratio must be 1:1.<br/> Image must be (300 x 300) or grater.. </center>"; 
			echo "<script>var goback = setTimeout(function(){window.history.back();},5000);</script>";	
			exit;
		}	 */	
		if($ext=='jpg' || $ext=='jpeg' || $ext=='png' || $ext=='jpeg' || $ext=='gif' || $ext=='bmp'){
			$getrec1=$db->singlerec("select prodimg4 from product where id='$idvalue'");
			$prdimg4=$getrec1['prodimg4'];
			if($prdimg4 !="noimages.jpg"){@unlink("../uploads/prodimg/40x40/$prdimg4");@unlink("../uploads/prodimg/400x400/$prdimg4");}
			$NgImg = $idvalue."4".".".$ext;
			$img_org = "../uploads/prodimg/$NgImg";	
			$img_size = "../uploads/prodimg/400x400/$NgImg";
			$img_thum = "../uploads/prodimg/40x40/$NgImg";
			move_uploaded_file($fpath,$img_org);
			$resizeObj = new resize($img_org);			
			$resizeObj -> resizeImage(400, 400, 'exact');
			$resizeObj -> saveImage($img_size, 72);
			$resizeObj -> resizeImage(40, 40, 'exact');
			$resizeObj -> saveImage($img_thum, 72);
			@unlink($img_org);
			$db->insertrec("update product set prodimg4='$NgImg' where id='$idvalue';");
		}
		else{
		echo "<center style='color:red;'>jpg or png file will only accepted..</center>";
		}
	}
	echo "<script>location.href='product.php?act=$act';</script>";
	header("location:product.php?act=$act");
	exit;	
	}
		
$GetRecord = $db->singlerec("select * from product where id='$id'");
@extract($GetRecord);
$prod_name=$prod_name;
$prod_details=$prod_details;
$slist = "<option value=''>- - Select- -</option>";
$sclist = "<option value=''>- - Select- -</option>";
if($prod_cateid){
	$slist = "<option value=''>- - Select- -</option>";
	$DropDownQry = "select id as prod_cateid,name from category where cat_id='$prod_catid' order by name asc";
	$slist .= $drop->get_dropdown($db,$DropDownQry,$prod_cateid);
	$sclist = "<option value=''>- - Select- -</option>";
	$DropDownQry = "select id as prod_subcatid,name from category where cat_id='$prod_catid' and parent_id='$prod_cateid' order by name asc";
	$sclist .= $drop->get_dropdown($db,$DropDownQry,$prod_subcatid);
}
	

$mlist = "<option value=''>- - Select- -</option>";
$DropDownQry = "select id as prod_catid,name from maincategory order by name asc";
$mlist .= $drop->get_dropdown($db,$DropDownQry,$prod_catid);

if($act == "ps")
	$Message = "<b><font color='red'>atleast 4 minimum character need!!!...</font></b>";
if($act=="exit_nam")
	$Message="<b><font color='red'>Username already exits.</font><b>";
if($act=="exit_email")
	$Message="<b><font color='red'>Email-ID already exits.</font><b>";
?>
<script src="//tinymce.cachefly.net/4.1/tinymce.min.js"></script>
<script type="text/javascript" src="js/tinymce.js" ></script>
<script src="js/product.js" type="text/javascript"></script>
<div class="boxed">
	<!--CONTENT CONTAINER-->
	<!--===================================================-->
	<div id="content-container">
		<?php include "header_nav.php"; ?>
		<div class="pageheader">
			<h3><i class="fa fa-users"></i>Product </h3>
			<div class="breadcrumb-wrapper">
				<span class="label">You are here:</span>
				<ol class="breadcrumb">
					<li> <a href="welcome.php"> Home </a> </li>
					<li class="active"> Product </li>
				</ol>
			</div>
		</div>
		<!--Page content-->
		<!--===================================================-->
		<div id="page-content">
            <div class="row">
                <div class="col-md-12">
                    <section class="panel">
                        <div class="panel-heading">
                            <h3 class="panel-title">Product <?php echo $Message;?></h3>
                         </div>
                         <div class="panel-body">
                         <!-- START Form Wizard -->
                        <form class="form-horizontal form-bordered" action="productupd.php"  enctype="multipart/form-data" method="POST">
						<input type="hidden" name="upd" value="<?php echo $upd;?>">
						<input type="hidden" name="idvalue" value="<?php echo $id;?>">
								<div class="form-group">
									<label class="col-sm-2 control-label"> Select Category 1 : </label>
									<div class="col-sm-6">
									<select name="prod_catid" id="prod_catid" class="form-control" onchange="mcatfn(this.value);"><?php echo $mlist;?></select>
									</div>
								</div>
								<div class="form-group">
									<label class="col-sm-2 control-label"> Select Category 2 : </label>
									<div class="col-sm-6">
									<select name="prod_cateid" id="prod_cateid" class="form-control" onchange="subcatfn(this.value);"><?php echo $slist;?></select>
									</div>
								</div>
								<div class="form-group">
									<label class="col-sm-2 control-label"> Select Category 3 : </label>
									<div class="col-sm-6">
									<select name="prod_subcatid" id="prod_subcatid" class="form-control" ><?php echo $sclist;?></select>
									</div>
								</div>
								<div class="form-group">
									<label class="col-sm-2 control-label"> Product Name : </label>
									<div class="col-sm-6">
										<input type="text" name="prod_name" id="prod_name" value="<?php echo $prod_name; ?>"class="form-control" data-parsley-group="order" data-parsley-required />
									</div>
								</div>
								<div class="form-group">
									<label class="col-sm-2 control-label"> Version : </label>
									<div class="col-sm-6">
										<input type="text" name="max_supply_quantity" value="<?php echo $max_supply_quantity; ?>"class="form-control" data-parsley-group="order" data-parsley-required />
									</div>
								</div>
								<div class="form-group">
									<label class="col-sm-2 control-label"> Min Price : </label>
									<div class="col-sm-6">
										<input type="text" name="prod_minprice" id="prod_minprice" value="<?php echo $prod_minprice; ?>"class="form-control" data-parsley-group="order" data-parsley-required />
									</div>
								</div>
								<div class="form-group">
									<label class="col-sm-2 control-label"> Max Price : </label>
									<div class="col-sm-6">
										<input type="text" name="prod_maxprice" id="prod_maxprice" value="<?php echo $prod_maxprice; ?>"class="form-control" data-parsley-group="order" data-parsley-required />
									</div>
								</div>
								<div class="form-group">
									<label class="col-sm-2 control-label"> Sale Type : </label>
									<div class="col-sm-6"><?php echo $com_obj->drop_down($PS_Sale,$saletype,"saletype");?></div>
								</div>

								<div class="form-group">
									<label class="col-sm-2 control-label"> Short Description : </label>
									<div class="col-sm-6">
										<textarea name="short_prod_details" id="short_prod_details" class="form-control tiny" /><?php echo $short_prod_details; ?></textarea> 
									</div>
								</div>

								<div class="form-group">
									<label class="col-sm-2 control-label"> Description : </label>
									<div class="col-sm-6">
										<textarea name="prod_details" id="prod_details" class="form-control tiny" /><?php echo $prod_details; ?></textarea> 
									</div>
								</div>
								<div class="form-group">
									<label class="col-sm-2 control-label"> Addional Info : </label>
									<div class="col-sm-6">
										<textarea name="additionalinfo" class="tiny" /><?php echo $additionalinfo; ?></textarea> 
									</div>
								</div>
								<div class="form-group">
									<label class="col-sm-2 control-label"> user demo : </label>
									<div class="col-sm-6">
									<input type='text' name='userurl' class='form-control' value="<?php echo $userurl; ?>">   
									</div>
								</div>
								<div class="form-group">
									<label class="col-sm-2 control-label"> admin demo : </label>
									<div class="col-sm-6">
									<input type='text' name='adminurl' class='form-control'>   
									</div>
								</div>
								<div class="form-group">
									<label class="col-sm-2 control-label"> SEO Keyword : </label>
									<div class="col-sm-6">
									<input type='text' name='prod_keyword' class='form-control' value="<?php echo $prod_keyword;?>">   
									</div>
								</div>
								<div class="form-group">
									<label class="col-sm-2 control-label"> Multiple SEO Keywords : </label>
									<div class="col-sm-6">
									<input type='text' name='mutikeywords' class='form-control' value="<?php echo $mutikeywords;?>">   
									</div>
								</div>
								
								<div class="form-group">
									<label class="col-sm-2 control-label"> Select image 1 : </label>
									<div class="col-sm-6">
									<input type='file' name='prodimg' class='form-control'>   
									</div>
								</div>
								<div class="form-group">
									<label class="col-sm-2 control-label"> Select image 2 : </label>
									<div class="col-sm-6">
									<input type='file' name='prodimg2' class='form-control'>   
									</div>
								</div>
								<div class="form-group">
									<label class="col-sm-2 control-label"> Select image 3 : </label>
									<div class="col-sm-6">
									<input type='file' name='prodimg3' class='form-control'>   
									</div>
								</div>
								<div class="form-group">
									<label class="col-sm-2 control-label"> Select image 4 : </label>
									<div class="col-sm-6">
									<input type='file' name='prodimg4' class='form-control'>   
									</div>
								</div>
								
								<div class="form-group">
									<div class="col-sm-6">
										<input type="submit" name="submit" value="submit" class="btn btn-primary">
									</div>
								</div>
							<!--/ Wizard Container 1 -->
						</form>
						<!--/ END Form Wizard -->
					</div>
				</section>
			</div>
		</div>
	</div>
		<!--===================================================-->
		<!--End page content-->
	</div>
	<!--===================================================-->
	<!--END CONTENT CONTAINER-->
	<?php include "leftmenu.php"; ?>
</div>
<?php include "footer.php"; ?>