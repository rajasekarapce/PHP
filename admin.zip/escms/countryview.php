<?php include "header.php"; ?>
            <!--===================================================-->
            <!--END NAVBAR-->
            <div class="boxed">
                <!--CONTENT CONTAINER-->
                <!--===================================================-->
                <div id="content-container">
                    <?php include "header_nav.php"; ?>
                    <div class="pageheader">
                        <h3><i class="fa fa-home"></i> Country </h3>
                        <div class="breadcrumb-wrapper">
                            <span class="label">You are here:</span>
                            <ol class="breadcrumb">
                                <li> <a href="welcome.php"> Home </a> </li>
                                <li class="active">Country </li>
                            </ol>
                        </div>
                    </div>
<?php
$country_auto_id = isSet($country_auto_id) ? $country_auto_id : '' ;
$page = isSet($page) ? $page : '' ;
$crcdt=date("Y.m.d");
$GetRecordView = $db->singlerec("select * from country where country_auto_id='$country_auto_id'");
@extract($GetRecordView);
$GetRefereBy = $db->get_all("select * from country where country_auto_id='$country_auto_id'");
@extract($GetRefereBy);
?>
       <!--Page content-->
                    <!--===================================================-->
                    <div id="page-content">
                        <!-- Basic Data Tables -->
                        <!--===================================================-->
						<h3>View Country Details</h3><a href="country.php"  class="btn btn-success">Back</a></br>
                        <div class="panel">
                            <div class="panel-heading">
                            </div>
                            <div class="panel-body">
								<table>
                                    <thead>
                                        <tr>
											<td>Name</td><td width="75">:</td><td><?php echo $country_name;?></td>
										</tr>
                                        <tr>
											<td>Currency</td><td width="75">:</td><td><?php echo $currency;?></td>
										</tr>
                                        <tr>
											<td>Country code</td><td width="75">:</td><td><?php echo $country_code;?></td>
										</tr>
                                        <tr>
											<td>Symbol</td><td width="75">:</td><td><?php echo $symbol;?></td>
										</tr>
										<tr>
											<td>Created</td><td width="75">:</td><td><?php echo $crcdt=date("Y.m.d"); ?></td>
										</tr>
                                    </thead>
                                </table>
                            </div>
                        </div>
                    </div>
                    <!--===================================================-->
                    <!--End page content-->
                </div>
                <!--===================================================-->
                <!--END CONTENT CONTAINER-->
			<?php include "leftmenu.php"; ?>	
            </div>
<?php

include "footer.php";
?>