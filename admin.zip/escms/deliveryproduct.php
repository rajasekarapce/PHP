<?php include "header.php"; ?>
            <!--===================================================-->
            <!--END NAVBAR-->
            <div class="boxed">
                <!--CONTENT CONTAINER-->
                <!--===================================================-->
                <div id="content-container">
                    <?php include "header_nav.php"; ?>
                    <div class="pageheader">
                        <h3><i class="fa fa-users"></i> Product </h3>
                        <div class="breadcrumb-wrapper">
                            <span class="label">You are here:</span>
                            <ol class="breadcrumb">
                                <li> <a href="welcome.php"> Home </a> </li>
                                <li class="active">Product </li>
                            </ol>
                        </div>
                    </div>
<?php	
$status = isSet($status) ? $status : '' ;
$id = isSet($id) ? $id : '' ;
$act = isSet($act) ? $act : '' ;
$Message = isSet($Message) ? $Message : '' ;
$records = $GT_RecPerPage;

if($act == "del") {
	$crmdt=date("Y-m-d");
    $db->insertrec("update orderno set deliveryst='1',deliverydt='$crmdt' where id='$id'");
    header("location:deliveryproduct.php?act=sts");
    exit ;
}

$GetRecord=$db->get_all("select * from orderno order by id desc");
$disp = "";
for($i=0;$i<count($GetRecord);$i++) {  
    $idvalue = $GetRecord[$i]['id'];
	$prod_id=$GetRecord[$i]['prod_id'];
	$price=$GetRecord[$i]['price'];	
	$ordrno=$GetRecord[$i]['ordrno'];
	$name=$GetRecord[$i]['name'];
	$emailid=$GetRecord[$i]['emailid'];
	$mbl=$GetRecord[$i]['mbl'];
	$addr=$GetRecord[$i]['addr'];
	$cfrmdt=$GetRecord[$i]['cfrmdt'];
	$deliverydt=$GetRecord[$i]['deliverydt'];
	$deliveryst=$GetRecord[$i]['deliveryst'];
	$user_id=$GetRecord[$i]['user_id'];
	$prodnam=$db->Extract_Single("select prod_name from product where find_in_set(id,'$prod_id')");
	$unam=$db->Extract_Single("select email from register where find_in_set(id,'$user_id')");
	$slno = $i + 1 ;
    if($deliveryst == '0'){
        $DisplayStatus = "<font color='red'>Not Deliver</font>";
	}	
    else if($deliveryst == '1'){
        $DisplayStatus = "<font color='green'>Delivered</font>";
	}
    $disp .="<tr><td>$slno</td>
				<td>$unam</td>
				<td>$ordrno</td>
				<td>$cfrmdt</td>
				<td>$prodnam</td>
				<td>$price</td>
				<td>$name<br/>$mbl<br/>$addr</td>
				<td>$deliverydt</td>
				<td><b>$DisplayStatus</b></td>
				<td>
					<a href='deliveryproduct.php?id=$idvalue&act=del' class='btn btn-default' data-toggle='tooltip'>Change</a>
				</td>
			</tr>";
}
if($act == "sts")
    $Message = "<font color='green'><b>Status Changed Successfully</b></font>" ;
?>
                    <!--Page content-->
                    <!--===================================================-->
                    <div id="page-content">
                        <!-- Basic Data Tables -->
                        <!--===================================================-->
                        <div class="panel">
                            <div class="panel-heading">
                                <h3 class="panel-title"><?php echo $Message;?></h3>
                            </div>
                            <div class="panel-body">
							    <table id="demo-dt-basic" class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
											<th>SlNo</th>
											<th>OrderBy</th>
											<th>OrderNo</th>
											<th>OrderDate</th>
											<th>ProductName</th>
											<th>Price</th>
											<th>DeliverAddress</th>
											<th>DeliverDate</th>
											<th>Status</th>
											<th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody><?php echo $disp; ?></tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <!--===================================================-->
                    <!--End page content-->
                </div>
                <!--===================================================-->
                <!--END CONTENT CONTAINER-->
			<?php include "leftmenu.php"; ?>	
            </div>
<?php include "footer.php"; ?>