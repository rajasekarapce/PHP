<?php include"header.php"; ?>
<div class="boxed">
	<!--CONTENT CONTAINER-->
	<!--===================================================-->
	<div id="content-container">
		<?php include "header_nav.php"; ?>
		<div class="pageheader">
			<h3><i class="fa fa-home"></i>Country </h3>
			<div class="breadcrumb-wrapper">
				<span class="label">You are here:</span>
				<ol class="breadcrumb">
					<li> <a href="welcome.php"> Home </a> </li>
					<li class="active"> Country </li>
				</ol>
			</div>
		</div>
		
<?php
$upd = isset($upd)?$upd:'';
$country_auto_id = isSet($country_auto_id) ? $country_auto_id : '' ;
$act  = isSet($act) ? $act : '' ;
$page  = isSet($page) ? $page : '' ;
$Message  = isSet($Message) ? $Message : '' ;
$country_name = isSet($country_name) ? $country_name : '' ;
$currency = isSet($currency) ? $currency : '' ;
$country_code = isSet($country_code) ? $country_code : '' ;
$symbol = isSet($symbol) ? $symbol : '' ;
if($submit) {
    $crcdt = time();
    $country_name  = trim(addslashes($country_name));
	$checkStatus = $db->check1column("country","country_name",$country_name);
	if($country_name != ''){
		if($upd == 2)
			$checkStatus = 0;
			
		if($checkStatus == 0){
			$set  = "country_name = '$country_name'";
			$set  .= ",currency = '$currency'";
			$set  .= ",country_code = '$country_code'";
			$set  .= ",symbol = '$symbol'";
			if($upd == 1){
				$set  .= ",crcdt = '$crcdt'";    
				$set  .= ",active_status = '1'";
				$db->insertrec("insert into country set $set");
				$act = "add";
			}
			else if($upd == 2){
				$set  .= ",chngdt = '$crcdt'";
				$db->insertrec("update country set $set where country_auto_id='$country_auto_id'");
				$act = "upd";
			}
			header("location:country.php?&page=$pg&act=$act");
			exit;
		}else{
			$upd = $upd ;
			$Message = "<font color='red'>$country_name Already Exit</font>";
		}
    } 
	else{
		$upd = $upd ;
		$Message = "<font color='red'>Input Fields Marked With * are compulsory</font>";
	}
}
if($upd==1){
	$TextChange = "Add";
}
else if($upd==2){
	$TextChange = "Update";
	$Getmaincat=$db->singlerec("select * from country where country_auto_id='$country_auto_id'");
    $country_name = stripslashes($Getmaincat['country_name']);
    $currency = stripslashes($Getmaincat['currency']);
    $country_code = stripslashes($Getmaincat['country_code']);
    $symbol = stripslashes($Getmaincat['symbol']);
}


?>
		
			<!--Page content-->
		<!--===================================================-->
		<div id="page-content">
			<div class="row">
			  <div class="eq-height">
				 <div class="col-sm-6 eq-box-sm">
					<div class="panel">
						<div class="panel-heading">
							<h3 class="panel-title"><?php echo $TextChange;?> Country</h3>
						</div>
						<form class="form-horizontal" method="post" action="">
							<input type="hidden" name="idvalue" value="<?php echo $id;?>" />
							<input type="hidden" name="upd" value="<?php echo $upd;?>" />							
							<div class="panel-body">
								<table style="padding:25px;">
									<tr>
										<td>Name <font color="red">*</font></td>
										<td><input type="text" name="country_name" id="country_name" value="<?php echo $country_name; ?>" class="form-control">
										</td>
									</tr>
									<tr>
										<td>currency <font color="red">*</font></td>
										<td><input type="text" name="currency" id="currency" value="<?php echo $currency; ?>" class="form-control">
										</td>
									</tr>
									<tr>
										<td>country_code <font color="red">*</font></td>
										<td><input type="text" name="country_code" id="country_code" value="<?php echo $country_code; ?>" class="form-control">
										</td>
									</tr><tr>
										<td>symbol <font color="red">*</font></td>
										<td><input type="text" name="symbol" id="symbol" value="<?php echo $symbol; ?>" class="form-control">
										</td>
									</tr>
							    </table>
							</div>
							<div class="panel-footer text-left">
								<div class="col-md-4  text-right"><input class="btn btn-info" type="submit" name="submit" value="Submit"></div>
								<a class="btn btn-info" href="country.php">Cancel</a>
							</div>
						</form>
						<!--===================================================-->
						<!--End Horizontal Form-->
					</div>
				</div>
			  </div>
			</div>
		</div>
		<!--===================================================-->
		<!--End page content-->
	</div>
	<!--===================================================-->
	<!--END CONTENT CONTAINER-->
	<?php include "leftmenu.php"; ?>
</div>
<?php include "footer.php"; ?>