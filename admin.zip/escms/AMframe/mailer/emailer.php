<?php
require 'PHPMailerAutoload.php';
$mail = new PHPMailer;
function email_function($mail,$to,$mailurl,$subject,$msg){
	
	$mail->IsSMTP();                           
	$mail->SMTPDebug = 1;
	$mail->SMTPAuth = true; 
	$mail->SMTPSecure = 'ssl';
	$mail->Host = 'mail.easytoselect.com';  
	$mail->Port = 143;  
	$mail->IsHTML(true);     
	$mail->Username = 'support@easytoselect.com';         
	$mail->Password = 'easy@123';                         
	$mail->setFrom($mailurl, 'Easytoselect.com');      
	$mail->Subject = $subject;
	$mail->Body    = $msg;
	$mail->addAddress($to, 'Joe User');   
	
	if(!$mail->send()) {
	    $ret = 'Mailer Error: ' . $mail->ErrorInfo;
	} else {
	    $ret = "scs";
	}
    return $ret;
}
function enquiry_function($mail,$to,$mailurl,$subject,$msg){
	
	$mail->IsSMTP();                           
	$mail->SMTPDebug = 1;
	$mail->SMTPAuth = true; 
	$mail->SMTPSecure = 'ssl';
	$mail->Host = 'mail.easytoselect.com';  
	$mail->Port = 465;  
	$mail->IsHTML(true);     
	$mail->Username = 'support@easytoselect.com';         
	$mail->Password = 'easy@123';                         
	$mail->setFrom($mailurl, 'Easytoselect.com');      
	$mail->Subject = $subject;
	$mail->Body    = $msg;
	$mail->addAddress($to, 'Joe User');   
	
	if(!$mail->send()) {
	    $ret = 'Mailer Error: ' . $mail->ErrorInfo;
	} else {
	    $ret = "scs";
	}
    return $ret;
}
$from = $siteemail;
$to = $email;
$subject = "Confirm your account for Easytoselect";
$msg ="<body bgcolor='#E1E1E1' leftmargin='0' marginwidth='0' topmargin='0' marginheight='0' offset='0'><center style='background-color:#f1f1f1;'> <table bgcolor='#FFFFFF' border='0' cellpadding='0' cellspacing='0' width='620' style='color:#FFFFFF; background:#1976D2;'> <tr > <td align='center' valign='top' class='textContent' style='font-size:12px; font-family: Helvetica,Arial,sans-serif; padding:10px;'> Support Email: support@easytoselect.com </td> </tr> </table><table bgcolor='#FFFFFF' border='0' cellpadding='0' cellspacing='0' width='620' id='emailBody'> <tr><td align='center' valign='top'><table border='0' cellpadding='0' cellspacing='0' width='100%' style='color:#FFFFFF;' bgcolor='#ffffff'><tr><td align='center' valign='top'><table border='0' cellpadding='0' cellspacing='0' width='500' class='flexibleContainer'><tr><td align='center' valign='top' width='600' class='flexibleContainerCell'> <!-- // CONTENT TABLE --> <table border='0' cellpadding='15' cellspacing='0' width='100%'><tr><td align='center' valign='top' class='textContent'> <a href='http://www.easytoselect.com/' target='_blank'> <img src='http://www.easytoselect.com/images/logo.png' class='img-responsive'></a></td></tr></table><!-- // CONTENT TABLE --></td></tr></table><!-- // FLEXIBLE CONTAINER --></td></tr></table><table border='0' cellpadding='0' cellspacing='0' width='100%' style='color:#FFFFFF; border:0px solid #000; padding: 40px; background:#D3E6F9;' bgcolor='#ffffff'><tr><td align='center' valign='top'><table border='0' cellpadding='0' cellspacing='0' width='500' class='flexibleContainer'><tr><td align='center' valign='top' width='600' class='flexibleContainerCell'><table border='0' cellpadding='0' cellspacing='0' width='100%' style='font-size:16px;'><tr><td align='center' valign='top' class='textContent' style='font-size: 16px; font-family: Helvetica,Arial,sans-serif; color:#4C4C4C; font-weight: 600;'>To activate, click below link. If you believe this is an error, ignore this message and we'll never bother you again.</td></tr> <tr><td align='center' valign='top' class='textContent' style='padding-top: 30px;' ><a style='color:#FFFFFF;text-decoration:none;font-family:Helvetica,Arial,sans-serif;font-size:20px;line-height:135%; padding: 10px 20px; background: #F79118; border-radius: 30px;' href='$url' target='_blank'>Click here</a></td></tr></table><!-- // CONTENT TABLE --></td></tr></table><!-- // FLEXIBLE CONTAINER --></td></tr></table><!-- // CENTERING TABLE --> <table border='0' cellpadding='0' cellspacing='0' width='100%' style='color:#FFFFFF; border:0px solid #000; padding: 10px; background:#1976D2;'> <tr> <td></td> </tr> </table> <table border='0' cellpadding='0' cellspacing='0' width='100%' style='color:#FFFFFF; border:0px solid #000; padding:26px; background:#d8dde4;'> <tr> <td align='center' style='color:#999;'> <table width='200' border='0' cellspacing='2' cellpadding='0'> <tr> <td><a href='www.facebook.com' target='_blank'><img src='http://www.easytoselect.com/images/facebook.png' width='32'></a></td> <td><a href='https://twitter.com' target='_blank'><img src='http://www.easytoselect.com/images/twitter.png' width='32'></a></td> <td><a href='https://plus.google.com/' target='_blank'><img src='http://www.easytoselect.com/images/google-plus.png' width='32'></a></td> <td><a href='https://www.linkedin.com/' target='_blank'><img src='http://www.easytoselect.com/images/linkedin.png' width='32'></a></td> </tr> </table> </td> </tr> <tr> <td align='center' style='color:#999; font-family: Helvetica,Arial,sans-serif; font-size: 12px;'> Copyright &copy; 2016 www.easytoselect.com. All rights reserved. If you do not want to recieve emails from us. </td> </tr> </table> </td></tr><!-- // MODULE ROW --> </table> </center> </body>";
?>