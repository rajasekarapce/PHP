<?php
class database{	
		function database(){
			$host    = "localhost";
			$dbuser  = "root";
			$dbpass  = "";
			$dbname  = "monika";
			$dbh = mysql_connect($host,$dbuser,$dbpass);
			mysql_select_db($dbname);
			return $dbh;
			
			/* $host    = "localhost";
			$dbuser  = "getcover_jose";
			$dbpass  = "jose@#123";
			$dbname  = "getcover_josephin";
			$dbh = mysql_connect($host,$dbuser,$dbpass);
			mysql_select_db($dbname);
			return $dbh; */
		}
  //======================================================================================
		function insertrec($query){
			
			if(!mysql_query("$query")){
			$err1 = mysql_errno();
			$err2 = mysql_error();
			echo "$err1 $err2";
			exit;			
			}
			return;
		}
  //======================================================================================		
		function singlerec($query){
		{
        if (! ($result = mysql_query("$query"))) {
            $err1 = mysql_errno();
            $err2 = mysql_error();
            echo ("$query  $err1 $err2");
            exit;
        }
        $rw = mysql_fetch_array ($result);
        mysql_free_result ($result);
        return $rw;
		}
		}
		
  //======================================================================================				
		function singleasso($query){
		{
        if (! ($result = mysql_query("$query"))) {
            $err1 = mysql_errno();
            $err2 = mysql_error();
            echo ("$query  $err1 $err2");
            exit;
        }
        $rw = mysql_fetch_assoc($result);
        mysql_free_result ($result);
        return $rw;
		}
		}
		
  //======================================================================================
		function get_all($query){
			$rst = mysql_query("$query");
			$result = array();
			$x=0;
			while($row=mysql_fetch_array($rst)){
				$result[$x] = $row;
				$x++;
				}				
				return $result;
			}
  //======================================================================================
		function get_all_assoc($query){
			$rst = mysql_query("$query");
			$result = array();
			$x=0;
			while($row=mysql_fetch_assoc($rst)){
				$result[$x] = $row;
				$x++;
				}				
				return $result;
			}
  //======================================================================================
		function insertid($query) {
        if (!mysql_query ("$query")) {
            $err1 = mysql_errno();
            $err2 = mysql_error();
            echo ("<h4>$query  $err1 $err2</h4>");
            exit;
        }
        $rwId=mysql_insert_id();
        return $rwId;
    }
  //======================================================================================	
  function singlecolumn ($mysql) {
        $x = 0;
        $result = mysql_query($mysql);
        $q = array() ;
        while ($row = mysql_fetch_array ($result) ) {
            $q[$x] = $row[0];
            $x++;
        }
        mysql_free_result ($result);
        return $q;
    }
	//======================================================================================	
	function Extract_Single($query)
    {
        $x = 0;
        $result = mysql_query($query);
        while ( $row = mysql_fetch_array ($result) ) {
            $q[$x] = $row[0];
            $implode[] = $q[$x] ;
            $x++;
        }
        mysql_free_result ($result);
        return @implode(',', $implode);
    }
//======================================================================================	
	function check1column($table,$column,$v1) {
        if (! $result=mysql_query ("select * from $table where $column ='$v1'")) {
            $men = mysql_errno();
            $mem = mysql_error();
            echo ("<h4>$mysql  $men $mem</h4>");
            exit();
        }
        $row=mysql_fetch_array ($result);
        mysql_free_result ($result);
        if ($row[0])
            $var =  1;
        else
            $var =  0;
        return $var;
    }
  //======================================================================================	
       function check2column($table,$column1,$v1,$column2,$v2) {
        if (! $result=mysql_query ("select * from $table where $column2 ='$v2' and $column1='$v1'")) {
            $men = mysql_errno();
            $mem = mysql_error();
            echo ("<h4>$mysql  $men $mem</h4>");
            exit();
        }
        $row=mysql_fetch_array ($result);
        mysql_free_result ($result);
        if ($row[0])
            $var =  1;
        else
            $var =  0;
        return $var;
    }
    //======================================================================================
	/* Pagination*/
    //==========================================================================================================
    /* function page_break($count,$records,$page){
		$livepage = $_SERVER["PHP_SELF"];
		$livepage = substr(strrchr($livepage, '/'), 1);
		$disp="";
		if($records < $count){
			if(5<=$page){
				if($page==5){
					$_SESSION['limit']=10;
					$_SESSION['start']=5;
					for($i=5;$i<10;$i++){
						$slno=$i+1;
						$link="$livepage?page=".$slno;
						$disp .="<li><a href='$link'>$slno</a></li>";
					}
				}
				else{
					$rw=$page / 5;
					if($page % 5==0 && $_SESSION['duplicate']==""){
						$limit=bcadd($rw,1,0) * 5;
						$_SESSION['limit']=$limit;
						$_SESSION['start']=bcadd($_SESSION['start'],5,0);
						$start=$_SESSION['start'];
						$_SESSION['duplicate']=1;
					}
					else{
						$limit=$_SESSION['limit'];
						$start=$_SESSION['start'];
					}
					for($i=$start;$i<$limit;$i++){
						$slno=$i+1;
						$link="$livepage?page=".$slno;
						$disp .="<li><a href='$link'>$slno</a></li>";
					}
				}
			}
			else{
				for($i=0;$i<5;$i++){
					$slno=$i+1;
					$link="$livepage?page=".$slno;
					$disp .="<li><a href='$link'>$slno</a></li>";
				}
			}
		}
		else{
			unset($_SESSION['limit']);
			unset($_SESSION['start']);
		}		
		return $disp;	
    } */
	function page_break($count,$records,$page){
		$livepage = $_SERVER["PHP_SELF"];
		$livepage = substr(strrchr($livepage, '/'), 1);
		$disp="";
		if($records < $count){
			$limit=$count / $records;
			for($i=0;$i<$limit;$i++){
				$slno=$i+1;
				$link="$livepage?page=".$slno;
				$disp .="<li><a href='$link'>$slno</a></li>";
			}
		}
		else{
			unset($_SESSION['limit']);
			unset($_SESSION['start']);
		}		
		return $disp;	
    }
	//========================================================================	
}

	$GT_vadmin = 1;
//========================================================================
while(list($key,$value)=@each($_POST)) {
	$$key=$value;
}

while(list($key,$value)=@each($_GET)) {
    $$key=$value;
}	
?>