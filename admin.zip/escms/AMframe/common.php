<?php
class common extends database {
	function drop_down($PS_Sale,$getval,$getname){
		$list = "";
		for($astrn=1; $astrn<count($PS_Sale); $astrn++){
			$dropval=$PS_Sale[$astrn];
			if($astrn == $getval)
				$list .= "<input type='radio' name='$getname' value='$astrn' checked>$dropval &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
			else	
				$list .= " <input type='radio' name='$getname' value='$astrn'>$dropval &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
		}
		return $list;
	}
	//========================================================================	
	function dropdown($array,$getval,$getname){
		$list = "<option value='0'>--select--</option>";
		for($astrn=1; $astrn<count($array); $astrn++){
			if($astrn == $getval)
				$list .= "<option value='$astrn' selected>$array[$astrn]</option>";
			else	
				$list .= "<option value='$astrn'>$array[$astrn]</option>";
		}
		return $list;
	}
	//========================================================================	
	function dropdown_support($array,$getval){
		$list = "<option value='0'>--select--</option>";
		for($astrn=1; $astrn<count($array); $astrn++){
			if($astrn==1){$astr=1;}else if($astrn==2){$astr=7;}else if($astrn==3){$astr=10;}
			if($astr == $getval)
				$list .= "<option value='$astr' selected>$array[$astrn]</option>";
			else	
				$list .= "<option value='$astr'>$array[$astrn]</option>";
		}
		return $list;
	}
	function dropdown_array_view($array,$getval){
		$ret = $array[$getval];
		return $ret;
	}
	//========================================================================	
	function drop_down_view($array,$getval){
		$list = "";
		for($astrn=1; $astrn<count($array); $astrn++){
			if($astrn == $getval)
				$list .= $array[$astrn];
		}
		return $list;
	}
	function counting_days(){
		$start = '2015-01-01';
		$end = date("Y/m/d");
		$diff = (strtotime($end)- strtotime($start))/24/3600; 
		
		return $diff;
	}
	//========================================================================	
	function drop_down_mail($array,$getval){
		$list = $array[$getval];
		return $list;
	}
	//========================================================================	
	function first_letter($string){
		$expr = '/(?<=\s|^)[a-z]/i';
		preg_match_all($expr, $string, $matches);
		$result = implode('', $matches[0]);
		$result = strtoupper($result);
		return $result;
	}
	//========================================================================	
	function int_val($string){
		$ret = preg_replace("/[^0-9]/","",$string);
		return $ret;
	}
	//=======================================================================
	function character($string){
		$ret = preg_replace('/[^A-Za-z]/', '', $string);
		return $ret;
	}
	//=======================================================================
	function user_profile_id($getid){
		$array = array("","00000","0000","000","00","0");
		$charval = preg_replace('/[^A-Za-z]/', '', $getid);
		$getrec = database::singlerec("select user_profileid from register where user_profileid like '%$charval%' order by user_profileid desc");
		$userprofileid = $getrec['user_profileid'];
		if($userprofileid=="")
			$userprofileid=$getid;

		$intval = preg_replace("/[^0-9]/","",$userprofileid);
		$incval = bcadd($intval,1,0);
		$stlen = strlen($incval);
		$zero = $array[$stlen];
		$ret = $charval.$zero.$incval;
		return $ret;
	}
	//========================================================================	
	function hidecontrols($string){
		if($string == "Admin")
			$ret = "";
		else
			$ret = "<style>.btn-default{display:none;} .cntrhid{display:none;}</style>";
		
		return $ret;
	}
	function datetimestamp($getdate){
		$DateArr = @split("/",$getdate);
		@list($bkDate,$bkMonth,$bkYear) = $DateArr;
		$ret = @mktime(0,0,0,$bkMonth,$bkDate,$bkYear);
		return $ret;
	}
	function expired_dt($call_dt,$tot_month){
		if($call_dt !=""){
			$DateArr = @split("/",$call_dt);
			@list($bkDate,$bkMonth,$bkYear) = $DateArr;
			$ret = @mktime(0,0,0,$bkMonth+$tot_month,$bkDate,$bkYear);
			$ret = date("d/m/Y",$ret);
		}
		else{
			$ret = "";
		}
		return $ret;
	}
	function opt_num(){
		$ret = mt_rand(100000, 999999);
		return $ret;
	}
	function email($from,$to,$subject,$message){
		
		$headers .='Reply-To: '. $to . "\r\n" ;
		$headers .='X-Mailer: PHP/' . phpversion();
		$headers  = 'MIME-Version: 1.0' . "\r\n";
		$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
		$headers .= 'From: <'.$from.'>' . "\r\n";
		@mail($to, $subject, $message, $headers);
	}
	function singup_mail($from,$to,$url){
		$subject = "Confirm your account for Easytoselect";
		$message ="<body bgcolor='#E1E1E1' leftmargin='0' marginwidth='0' topmargin='0' marginheight='0' offset='0'><center style='background-color:#f1f1f1;'> <table bgcolor='#FFFFFF' border='0' cellpadding='0' cellspacing='0' width='620' style='color:#FFFFFF; background:#1976D2;'> <tr > <td align='center' valign='top' class='textContent' style='font-size:12px; font-family: Helvetica,Arial,sans-serif; padding:10px;'> Support Email: support@easytoselect.com </td> </tr> </table><table bgcolor='#FFFFFF' border='0' cellpadding='0' cellspacing='0' width='620' id='emailBody'> <tr><td align='center' valign='top'><table border='0' cellpadding='0' cellspacing='0' width='100%' style='color:#FFFFFF;' bgcolor='#ffffff'><tr><td align='center' valign='top'><table border='0' cellpadding='0' cellspacing='0' width='500' class='flexibleContainer'><tr><td align='center' valign='top' width='600' class='flexibleContainerCell'> <!-- // CONTENT TABLE --> <table border='0' cellpadding='15' cellspacing='0' width='100%'><tr><td align='center' valign='top' class='textContent'> <a href='http://www.easytoselect.com/' target='_blank'> <img src='http://www.easytoselect.com/images/logo.png' class='img-responsive'></a></td></tr></table><!-- // CONTENT TABLE --></td></tr></table><!-- // FLEXIBLE CONTAINER --></td></tr></table><table border='0' cellpadding='0' cellspacing='0' width='100%' style='color:#FFFFFF; border:0px solid #000; padding: 40px; background:#D3E6F9;' bgcolor='#ffffff'><tr><td align='center' valign='top'><table border='0' cellpadding='0' cellspacing='0' width='500' class='flexibleContainer'><tr><td align='center' valign='top' width='600' class='flexibleContainerCell'><table border='0' cellpadding='0' cellspacing='0' width='100%' style='font-size:16px;'><tr><td align='center' valign='top' class='textContent' style='font-size: 16px; font-family: Helvetica,Arial,sans-serif; color:#4C4C4C; font-weight: 600;'>To activate, click below link. If you believe this is an error, ignore this message and we'll never bother you again.</td></tr> <tr><td align='center' valign='top' class='textContent' style='padding-top: 30px;' ><a style='color:#FFFFFF;text-decoration:none;font-family:Helvetica,Arial,sans-serif;font-size:20px;line-height:135%; padding: 10px 20px; background: #F79118; border-radius: 30px;' href='$url' target='_blank'>Click here</a></td></tr></table><!-- // CONTENT TABLE --></td></tr></table><!-- // FLEXIBLE CONTAINER --></td></tr></table><!-- // CENTERING TABLE --> <table border='0' cellpadding='0' cellspacing='0' width='100%' style='color:#FFFFFF; border:0px solid #000; padding: 10px; background:#1976D2;'> <tr> <td></td> </tr> </table> <table border='0' cellpadding='0' cellspacing='0' width='100%' style='color:#FFFFFF; border:0px solid #000; padding:26px; background:#d8dde4;'> <tr> <td align='center' style='color:#999;'> <table width='200' border='0' cellspacing='2' cellpadding='0'> <tr> <td><a href='www.facebook.com' target='_blank'><img src='http://www.easytoselect.com/images/facebook.png' width='32'></a></td> <td><a href='https://twitter.com' target='_blank'><img src='http://www.easytoselect.com/images/twitter.png' width='32'></a></td> <td><a href='https://plus.google.com/' target='_blank'><img src='http://www.easytoselect.com/images/google-plus.png' width='32'></a></td> <td><a href='https://www.linkedin.com/' target='_blank'><img src='http://www.easytoselect.com/images/linkedin.png' width='32'></a></td> </tr> </table> </td> </tr> <tr> <td align='center' style='color:#999; font-family: Helvetica,Arial,sans-serif; font-size: 12px;'> Copyright &copy; 2016 www.easytoselect.com. All rights reserved. If you do not want to recieve emails from us. </td> </tr> </table> </td></tr><!-- // MODULE ROW --> </table> </center> </body>";
		$headers = "Content-type: text/html; charset=".$encoding." \r\n";
		$headers .='Reply-To: '. $to . "\r\n" ;
		//$headers .='X-Mailer: PHP/' . phpversion();
		$headers .= "MIME-Version: 1.0 \r\n";
		//$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
		$headers .= "Content-Transfer-Encoding: 8bit \r\n";
		$headers .= 'From: <'.$from.'>' . "\r\n";
		@mail($to, $subject, $message, $headers);
	//	echo $to."<br/>".$subject."<br/>".$from."<br/>".$message; die;
	}
	function month_days($fromdate){
		/* $DateArr = @explode("-",$fromdate);
		list($dtYear,$dtMonth,$dtDay) = $DateArr;
		$frmdate = $dtYear."-".$dtMonth."-".$dtDay; */
		$todate = date("Y-m-d");
		
		$date1 = strtotime($fromdate);
		$date2 = strtotime($todate);
		$months = 0;
		while (strtotime('+1 MONTH', $date1) < $date2) {
			$months++;
			$date1 = strtotime('+1 MONTH', $date1);
		}
		$ret = $months.' month,'. ($date2 - $date1) / (60*60*24) .' days'; 
		return $ret;
	}
	function timeconvert($from_time,$to_time){
	   $hours=intval($DepartureTime / 3600);
	   $mins=intval($DepartureTime / 60) % 60;
	   $secs=$DepartureTime % 60;
	   $trvaltime=sprintf("%d:%02d:%02d",$hours, $mins, $secs);
	}
	function calc_wallet($userid){
		$getwallet = database::singlerec("select amount as amt from wallet where user_id='$userid'");
		$ret=$getwallet['amt'];
		$ret=number_format((float)$ret,2, '.', '');
		return $ret;
	}
	function rating($product_id){
		$ret="";
		$rate_all=database::singlerec("SELECT sum(rating),count(rating) as rsum from rating where product_id='$product_id'");
		if($rate_all[1]!=0){
			$rate_avg = number_format((float)((int)$rate_all[0]/(int)$rate_all[1]),1, '.', '');	
			for($i=0;$i<5;$i++){
				if($i<(int)$rate_avg)
					$ret .="<i class='fa fa-star'></i>";
				else
					$ret .="<i class='fa fa-star-o'></i>";	
			}
			$ret .="&nbsp;(".$rate_avg.")";
		}
		else{
			$ret .="No reviews";	
		}
	return $ret;
	}
	function randuniq($id){
		$str='';
		$str.=substr(str_shuffle("01234123456789123489abcdeefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 4);
		$str.=$id;
		$str.=substr(rand(0,time()),-4);
		return $str;
	}
	function randuniq_temp($id){
		$str='';
		$str.=substr(str_shuffle("01234123456789123489abcdeefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 4);
		$str.=$id;
		$str.=substr(uniqid(),-4);
		return $str;
	}
	function notify_count(){
		$userlog=@($_SESSION['vyuserlog']?$_SESSION['vyuserlog']:'');
		
		$sql="select count(*) from notification where vendor_id='$userlog' and status='0'";
		
		$ntstv=database::singlerec("select notify_settings from store where own_by='$userlog'");
		$ntsarray=explode(',',$ntstv[0]);
		if(!empty($ntsarray)){
			$sql.="and (";	
			foreach($ntsarray as $index=>$sid){
				if(($index+1) < count($ntsarray))	
					$sql.=" notify_type = '$sid' or";
				else
					$sql.=" notify_type = '$sid'";	
			}
			$sql.=")";
		}else{
		$sql.=" and notify_type = '0'";	
		}
		
		$ntcount=database::singlerec($sql);
		$ret=$ntcount[0];
		return $ret;
	}
	function notification($date){
		$ret=date('h:i:s a',strtotime($date));
		return $ret;
	}
	
	function dtdiff($d1){
		$d1 = strtotime($d1);
		$d2 = time();
		$mindiff = round(($d2-$d1)/60);
		$hourdiff = round(($d2-$d1)/(60*60));
		$daydiff = round(($d2-$d1)/(60*60*24));
		
		//singular
		 if($mindiff==1){
			return 	'1 minute ago';
		}else if($hourdiff==1){
			return 	'1 hour ago';
		}else if($daydiff==1){
			return 	'1 day ago';	
		}else if(round($daydiff/7)==1){
			return 	'1 week ago';	
		}else if(round($daydiff/30)==1){
			return 	'1 month ago';	
		}else if(round($daydiff/365)==1){
			return 	'1 year ago';	
		}
		//flural
		if($mindiff == 0){
			return 	'just now';	
		}else if($mindiff<60){
			return 	$mindiff.' minutes ago';
		}else if($hourdiff<24){
			return 	$hourdiff.' hours ago';	
		}else if($daydiff<7){
			return 	$daydiff.' days ago';	
		}else if($daydiff<31){
			return 	round($daydiff/7).' weeks ago';	
		}else if($daydiff<365){
			return 	round($daydiff/30).' months ago';	
		}else if($daydiff>365){
			return 	round($daydiff/365).' years ago';	
		}
	}
	function PaymentSuccess($txnid){
		$lastid=$_SESSION["opid"];
		$set = "TranxId='$txnid'";
		$set .= ",PaymentStatus='paid'";
		database::insertrec("update checkout set $set where id='$lastid'");
	}
	function PaymentWireTransfer(){
		$lastid=$_SESSION["opid"];
		$set = "TranxId=''";
		$set .= ",PaymentStatus='approval waiting'";
		database::insertrec("update checkout set $set where id='$lastid'");
	}
	function ProdRating($prodid){
		$getrec=database::singlerec("select sum(`points`) as totr from rating where ProductId='$prodid'");
		$totr = $getrec['totr'];
		$getrec2=database::singlerec("select count(*) as totc from rating where ProductId='$prodid'");
		$totc = $getrec2['totc'];
		$ret = @bcdiv($totr,$totc,0);
		if($ret==1){
			$rt = "<img style='width:8%;' src='images/3.png'>
			<img style='width:8%;' src='images/1.png'>
			<img style='width:8%;' src='images/1.png'>
			<img style='width:8%;' src='images/1.png'>
			<img style='width:8%;' src='images/1.png'>";
		}
		else if($ret==2){
			$rt = "<img style='width:8%;' src='images/3.png'>
			<img style='width:8%;' src='images/3.png'>
			<img style='width:8%;' src='images/1.png'>
			<img style='width:8%;' src='images/1.png'>
			<img style='width:8%;' src='images/1.png'>";
		}	
		else if($ret==3){
			$rt = "<img style='width:8%;' src='images/3.png'>
			<img style='width:8%;' src='images/3.png'>
			<img style='width:8%;' src='images/3.png'>
			<img style='width:8%;' src='images/1.png'>
			<img style='width:8%;' src='images/1.png'>";
		}
		else if($ret==4){
			$rt = "<img style='width:8%;' src='images/3.png'>
			<img style='width:8%;' src='images/3.png'>
			<img style='width:8%;' src='images/3.png'>
			<img style='width:8%;' src='images/3.png'>
			<img style='width:8%;' src='images/1.png'>";
		}
		else if($ret==5){
			$rt = "<img style='width:8%;' src='images/3.png'>
			<img style='width:8%;' src='images/3.png'>
			<img style='width:8%;' src='images/3.png'>
			<img style='width:8%;' src='images/4.png'>
			<img style='width:8%;' src='images/1.png'>";
		}
		else{
			$rt = "<img src='images/1.png' style='width:8%;'>
			<img style='width:8%;' src='images/1.png'>
			<img style='width:8%;' src='images/1.png'>
			<img style='width:8%;' src='images/1.png'>
			<img style='width:8%;' src='images/1.png'>";
		}
	return $rt;	
	}
}	
?>